#!/usr/bin/env node

// Test script for HuggingFace background removal fallback
async function testHuggingFaceAPI() {
  const HUGGINGFACE_URL = 'https://not-lain-background-removal.hf.space/gradio_api/call/text';
  
  // Test with a sample image URL
  const testImageUrl = 'https://raw.githubusercontent.com/gradio-app/gradio/main/test/test_files/bus.png';
  
  console.log('Testing HuggingFace Background Removal API...');
  console.log('Using test image:', testImageUrl);
  
  try {
    // Step 1: Submit image for processing
    console.log('\n1. Submitting image for processing...');
    const response = await fetch(HUGGINGFACE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ data: [testImageUrl] })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    const { event_id } = await response.json();
    console.log('   Event ID received:', event_id);
    
    // Step 2: Wait and fetch results
    console.log('\n2. Fetching results (waiting 2 seconds)...');
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const resultResponse = await fetch(`${HUGGINGFACE_URL}/${event_id}`);
    
    if (!resultResponse.ok) {
      throw new Error(`Failed to fetch results: ${resultResponse.status}`);
    }
    
    const resultText = await resultResponse.text();
    
    // Parse Server-Sent Events format
    console.log('\n3. Parsing response...');
    const lines = resultText.split('\n');
    let resultUrl = null;
    
    for (const line of lines) {
      if (line.startsWith('data: ')) {
        try {
          const jsonData = JSON.parse(line.substring(6));
          if (jsonData?.[0]?.[1]?.url) {
            resultUrl = jsonData[0][1].url;
            break;
          } else if (jsonData?.[0]?.url) {
            resultUrl = jsonData[0].url;
            break;
          }
        } catch (e) {
          // Continue to next line
        }
      }
    }
    
    if (resultUrl) {
      console.log('\n✅ SUCCESS! Background removed image URL:');
      console.log('   ', resultUrl);
      console.log('\n🎉 HuggingFace API is working correctly as a fallback!');
      console.log('   The API will automatically be used if remove.bg fails or quota is exceeded.');
    } else {
      console.log('\n⚠️  Warning: Could not parse result URL from response');
      console.log('   Response preview:', resultText.substring(0, 200));
    }
    
  } catch (error) {
    console.error('\n❌ Error testing HuggingFace API:', error.message);
    console.log('   The API might be temporarily unavailable or the space might be sleeping.');
    console.log('   Try again in a few seconds as the space auto-wakes on first call.');
  }
}

// Run the test
testHuggingFaceAPI();