#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

// Test remove.bg API with a sample image
async function testRemoveBg() {
  const API_KEY = 'qaxYVvtnBz7omyNaVHRJcdyZ';
  const API_URL = 'https://api.remove.bg/v1.0/removebg';
  
  try {
    // Read the cartoon image from demo folder
    const imagePath = path.join(__dirname, 'demo', 'cartoon.jpg');
    if (!fs.existsSync(imagePath)) {
      console.error('Test image not found at:', imagePath);
      return;
    }
    
    const imageBuffer = fs.readFileSync(imagePath);
    
    // Create form data
    const FormData = require('form-data');
    const formData = new FormData();
    formData.append('image_file', imageBuffer, 'cartoon.jpg');
    formData.append('size', 'auto');
    formData.append('format', 'png');
    
    console.log('Testing remove.bg API...');
    
    // Make the API call
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'X-Api-Key': API_KEY,
        ...formData.getHeaders()
      },
      body: formData
    });
    
    if (!response.ok) {
      const error = await response.text();
      console.error('Remove.bg API error:', response.status, error);
      return;
    }
    
    // Save the result
    const resultBuffer = await response.arrayBuffer();
    const outputPath = path.join(__dirname, 'demo', 'cartoon_no_bg.png');
    fs.writeFileSync(outputPath, Buffer.from(resultBuffer));
    
    console.log('✅ Success! Background removed and saved to:', outputPath);
    console.log('The API is working correctly!');
    
  } catch (error) {
    console.error('Error testing remove.bg:', error);
  }
}

testRemoveBg();