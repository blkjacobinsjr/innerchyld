# HuggingFace Background Removal API Documentation

## Overview

This document describes the integration of HuggingFace's free background removal API as a fallback solution for transparent PNG generation in the Comixy comic creator app.

## API Details

- **Service**: HuggingFace Spaces
- **Space**: `not-lain/background-removal`
- **Cost**: **100% FREE** - Unlimited usage
- **API Type**: Gradio REST API
- **Output**: PNG with RGBA transparency
- **No API Key Required**: Works without authentication (optional HF token for priority)

## Why HuggingFace as Fallback?

1. **Zero Cost**: Completely free, no monthly limits
2. **No Registration**: Works immediately without signup
3. **Reliable**: Community-maintained, always available
4. **Good Quality**: Suitable for comic panels and character extraction
5. **Fast**: ~2 second processing time

## API Endpoints

### Primary Endpoint (URL-based)
```
POST https://not-lain-background-removal.hf.space/gradio_api/call/text
```
- Accepts image URLs
- Returns processed image with transparent background

### File Upload Endpoint
```
POST https://not-lain-background-removal.hf.space/gradio_api/call/png
```
- Accepts base64 encoded images
- Returns PNG file with transparency

## Implementation Flow

```mermaid
graph TD
    A[User uploads image] --> B{Primary API Available?}
    B -->|Yes| C[Use Remove.bg API]
    B -->|No| D[Fallback to HuggingFace]
    C -->|Success| E[Return transparent PNG]
    C -->|Failure| D
    D --> F[Call HF API]
    F --> G[Get Event ID]
    G --> H[Fetch Results]
    H --> E
```

## Usage Examples

### Basic Usage (JavaScript/React Native)

```javascript
async function removeBackgroundHF(imageUrl) {
    // Step 1: Submit image for processing
    const response = await fetch(
        'https://not-lain-background-removal.hf.space/gradio_api/call/text',
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ data: [imageUrl] })
        }
    );
    
    const { event_id } = await response.json();
    
    // Step 2: Fetch results
    const resultResponse = await fetch(
        `https://not-lain-background-removal.hf.space/gradio_api/call/text/${event_id}`
    );
    
    const resultText = await resultResponse.text();
    
    // Parse Server-Sent Events format
    const lines = resultText.split('\n');
    for (const line of lines) {
        if (line.startsWith('data: ')) {
            const jsonData = JSON.parse(line.substring(6));
            if (jsonData?.[0]?.[1]?.url) {
                return jsonData[0][1].url; // URL of transparent PNG
            }
        }
    }
    
    throw new Error('Failed to process image');
}
```

### With Error Handling and Retry

```javascript
async function removeBackgroundWithFallback(imageUrl, options = {}) {
    const { 
        primaryApiKey = null,
        maxRetries = 3,
        timeout = 10000 
    } = options;
    
    // Try primary API (Remove.bg) if key is available
    if (primaryApiKey) {
        try {
            return await removeBackgroundPrimary(imageUrl, primaryApiKey);
        } catch (error) {
            console.warn('Primary API failed, falling back to HuggingFace:', error);
        }
    }
    
    // Fallback to HuggingFace
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            return await removeBackgroundHF(imageUrl);
        } catch (error) {
            if (attempt === maxRetries) {
                throw new Error(`Failed after ${maxRetries} attempts: ${error.message}`);
            }
            // Wait before retry (exponential backoff)
            await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
        }
    }
}
```

## Integration with Comixy

### Service Configuration

Add to your environment variables (optional):
```bash
# Optional: HuggingFace token for priority queue
HF_TOKEN=hf_xxxxxxxxxxxxx

# Primary API (if available)
REMOVEBG_API_KEY=your_remove_bg_key
```

### Service Priority

1. **Primary**: Remove.bg (if API key configured)
   - Best quality
   - 50 free images/month
   - Fast processing

2. **Fallback**: HuggingFace
   - Always available
   - Unlimited free usage
   - Good quality

### Error Scenarios

The service automatically falls back to HuggingFace when:
- Remove.bg API key is not configured
- Remove.bg quota exceeded (after 50 free images)
- Remove.bg API is down or unreachable
- Network timeout on primary API

## Performance Characteristics

| Metric | HuggingFace | Remove.bg |
|--------|-------------|-----------|
| Processing Time | ~2 seconds | ~1 second |
| Image Quality | Good | Excellent |
| Max Resolution | 1024x1024 | 50MP (paid) |
| Batch Support | No | Yes |
| Rate Limits | None* | 500/min |

*Note: HuggingFace Spaces may have queue times during high usage

## Testing

### Test the API with curl

```bash
# Test with image URL
curl -X POST https://not-lain-background-removal.hf.space/gradio_api/call/text \
  -H "Content-Type: application/json" \
  -d '{"data": ["https://example.com/image.jpg"]}' \
  | jq -r '.event_id' \
  | xargs -I {} curl https://not-lain-background-removal.hf.space/gradio_api/call/text/{}
```

### Test Scripts

- `demo/test_hf_api_complete.mjs` - Complete test implementation
- `demo/test_huggingface_api.sh` - Bash/curl test script

## Limitations

1. **Queue Times**: May experience delays during peak usage
2. **No Batch Processing**: Processes one image at a time
3. **Resolution**: Best results with images under 1024x1024
4. **No Fine Control**: Cannot specify output quality or format options

## Best Practices

1. **Image Optimization**: Resize images to ~800px before processing
2. **Caching**: Cache processed images to avoid reprocessing
3. **User Feedback**: Show processing status during the ~2 second wait
4. **Error Messages**: Provide clear fallback messaging to users

## Troubleshooting

### Common Issues

1. **No Response**: Space might be sleeping
   - Solution: Retry after 5 seconds (auto-wakes on first call)

2. **Timeout**: Processing taking too long
   - Solution: Implement 10-second timeout and retry

3. **Invalid Response**: Malformed JSON or SSE
   - Solution: Parse defensively, check for multiple response formats

## Support and Resources

- **HuggingFace Space**: https://huggingface.co/spaces/not-lain/background-removal
- **API Status**: Check the space page for current status
- **Community**: HuggingFace Discord and Forums
- **Alternative Spaces**: Search "background removal" on HuggingFace for alternatives

## License

The HuggingFace background removal space is open source and free to use. No attribution required for commercial use.