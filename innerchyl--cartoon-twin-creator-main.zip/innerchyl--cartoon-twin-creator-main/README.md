# InnerChyl: Cartoon Twin Creator

Transform your photos into delightful cartoon-style avatars inspired by "Charlie and Lola"! Perfect for creating unique profile pictures for Instagram Stories and TikTok.

## Features

- 📸 **Photo to Cartoon Transformation**: Convert any photo into a charming cartoon avatar
- 🎨 **Charlie and Lola Art Style**: Unique artistic style with vibrant colors and playful design
- 📱 **Social Media Optimized**: Export in perfect dimensions for Instagram Stories (9:16), Posts (1:1), and TikTok
- 🎭 **Pose Matching**: Upload a pose reference to generate your cartoon twin in the same pose
- 🖼️ **Scene Creation**: Place your cartoon twin in custom scenes
- 🎯 **Background Removal**: Automatic background removal for clean avatars

## Prerequisites

- Node.js 18+ and npm/yarn/bun
- Expo CLI (`npm install -g expo-cli`)
- iOS Simulator (Mac) or Android Studio (for local development)
- Expo Go app (for testing on physical devices)

## Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/innerchyl-cartoon-twin-creator.git
   cd innerchyl-cartoon-twin-creator
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   bun install
   ```

3. **Configure API Keys**
   
   Copy the example environment file:
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` and add your API keys:
   ```bash
   # Required: Google Gemini API for AI features
   EXPO_PUBLIC_GEMINI_API_KEY=your-gemini-api-key-here
   
   # Optional: Remove.bg for higher quality background removal
   EXPO_PUBLIC_REMOVE_BG_API_KEY=your-remove-bg-key-here
   
   # Optional: HuggingFace token for priority processing
   HF_TOKEN=your-hf-token-here
   ```
   
   **Get your API keys:**
   - **Gemini API** (Required): [Google AI Studio](https://makersuite.google.com/app/apikey)
   - **Remove.bg** (Optional, 50 free/month): [Remove.bg API](https://www.remove.bg/api)
   - **HuggingFace** (Optional): [HuggingFace Settings](https://huggingface.co/settings/tokens)

4. **Start the development server**
   ```bash
   npm start
   # or
   expo start
   ```

5. **Run on your device**
   - Scan the QR code with Expo Go (Android) or Camera app (iOS)
   - Or press `i` for iOS simulator, `a` for Android emulator

## Technology Stack

- **Framework**: [Expo](https://expo.dev/) SDK 53 with React Native 0.79.1
- **Routing**: [Expo Router](https://docs.expo.dev/router/introduction/) (file-based)
- **State Management**: [Zustand](https://github.com/pmndrs/zustand) & [React Query](https://tanstack.com/query)
- **Styling**: [NativeWind](https://www.nativewind.dev/) (Tailwind for React Native)
- **TypeScript**: Full type safety with strict mode
- **AI**: Google Gemini 2.5 Flash for image generation and pose analysis

## Project Structure

```
/app/                 # Screens (Expo Router)
  ├── index.tsx       # Landing page
  ├── upload.tsx      # Photo selection
  ├── processing.tsx  # Cartoon generation
  ├── results.tsx     # Final result & sharing
  ├── pose-capture.tsx    # Pose reference upload
  ├── pose-processing.tsx # Pose analysis
  └── scene-editor.tsx    # Scene composition

/components/          # Reusable UI components
/services/           # API integrations
/hooks/              # Custom React hooks
/constants/          # Theme and configuration
```

## Features in Detail

### Basic Cartoon Generation
1. Upload or capture a photo
2. AI automatically generates a cartoon version in Charlie and Lola style
3. Background is automatically removed
4. Export in social media formats

### Pose Matching (Advanced)
1. Upload a reference pose photo
2. AI analyzes the pose using Gemini Vision
3. Generates your cartoon twin matching that pose
4. Perfect for creating dynamic scenes

### Scene Creation
1. Choose or upload a background
2. Position your cartoon twin
3. Add multiple twins in different poses
4. Export the complete scene

## Configuration Options

Edit `constants/config.ts` to customize:

- **Background Removal Service**: Choose between HuggingFace (free) or Remove.bg (better quality)
- **API Endpoints**: Configure different Gemini models
- **Style Prompts**: Customize the cartoon generation style

## Troubleshooting

### "Please configure your Gemini API key"
1. Make sure you've created a `.env` file from `.env.example`
2. Add your actual API key to the `.env` file
3. Restart the Expo development server

### Background removal not working
- Check if your Remove.bg API key is valid (if using Remove.bg service)
- HuggingFace service is free but may have occasional downtime
- Switch services in `constants/config.ts` if needed

### App crashes on photo selection
- Ensure you've granted camera and photo library permissions
- Check iOS Info.plist or Android permissions in `app.json`

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Inspired by the "Charlie and Lola" art style by Lauren Child
- Built with [Expo](https://expo.dev/) and [React Native](https://reactnative.dev/)
- Powered by [Google Gemini AI](https://ai.google.dev/)
- Background removal by [HuggingFace](https://huggingface.co/) and [Remove.bg](https://www.remove.bg/)

## Support

If you encounter any issues or have questions, please [open an issue](https://github.com/yourusername/innerchyl-cartoon-twin-creator/issues) on GitHub.

---

Made with ❤️ for creative expression and fun social media content!