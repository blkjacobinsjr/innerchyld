import React, { useEffect } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';
import { theme } from '@/constants/theme';

const { height } = Dimensions.get('window');

interface BlobBackgroundProps {
  colors?: string[];
  animated?: boolean;
}

export default function BlobBackground({ 
  colors = [theme.colors.lavender, theme.colors.sky, theme.colors.sunshine],
  animated = true 
}: BlobBackgroundProps) {
  const morphProgress = useSharedValue(0);
  const floatProgress = useSharedValue(0);

  useEffect(() => {
    if (animated) {
      morphProgress.value = withRepeat(
        withTiming(1, { duration: 8000 }),
        -1,
        true
      );
      
      floatProgress.value = withRepeat(
        withTiming(1, { duration: 6000 }),
        -1,
        true
      );
    }
  }, [animated, morphProgress, floatProgress]);

  const blob1Style = useAnimatedStyle(() => {
    const translateX = interpolate(floatProgress.value, [0, 1], [-20, 20]);
    const translateY = interpolate(morphProgress.value, [0, 1], [-10, 10]);
    const scale = interpolate(morphProgress.value, [0, 1], [1, 1.1]);
    
    return {
      transform: [
        { translateX },
        { translateY },
        { scale },
      ],
    };
  });

  const blob2Style = useAnimatedStyle(() => {
    const translateX = interpolate(floatProgress.value, [0, 1], [15, -15]);
    const translateY = interpolate(morphProgress.value, [0, 1], [10, -10]);
    const scale = interpolate(morphProgress.value, [0, 1], [1.1, 1]);
    
    return {
      transform: [
        { translateX },
        { translateY },
        { scale },
      ],
    };
  });

  const blob3Style = useAnimatedStyle(() => {
    const translateX = interpolate(floatProgress.value, [0, 1], [-10, 25]);
    const translateY = interpolate(morphProgress.value, [0, 1], [15, -5]);
    const scale = interpolate(morphProgress.value, [0, 1], [0.9, 1.2]);
    
    return {
      transform: [
        { translateX },
        { translateY },
        { scale },
      ],
    };
  });

  // SVG blob paths for organic shapes
  const blobPath1 = "M60,-60C80,-40,100,-20,100,0C100,20,80,40,60,60C40,80,20,100,0,100C-20,100,-40,80,-60,60C-80,40,-100,20,-100,0C-100,-20,-80,-40,-60,-60C-40,-80,-20,-100,0,-100C20,-100,40,-80,60,-60Z";
  const blobPath2 = "M50,-50C70,-30,90,-10,90,10C90,30,70,50,50,70C30,90,10,110,-10,110C-30,110,-50,90,-70,70C-90,50,-110,30,-110,10C-110,-10,-90,-30,-70,-50C-50,-70,-30,-90,-10,-90C10,-90,30,-70,50,-50Z";
  const blobPath3 = "M40,-40C60,-20,80,0,80,20C80,40,60,60,40,80C20,100,0,120,-20,120C-40,120,-60,100,-80,80C-100,60,-120,40,-120,20C-120,0,-100,-20,-80,-40C-60,-60,-40,-80,-20,-80C0,-80,20,-60,40,-40Z";

  return (
    <View style={styles.container}>
      <Animated.View style={[styles.blob, styles.blob1, blob1Style]}>
        <Svg width="200" height="200" viewBox="-100 -100 200 200">
          <Path d={blobPath1} fill={colors[0]} opacity={0.3} />
        </Svg>
      </Animated.View>
      
      <Animated.View style={[styles.blob, styles.blob2, blob2Style]}>
        <Svg width="150" height="150" viewBox="-100 -100 200 200">
          <Path d={blobPath2} fill={colors[1]} opacity={0.25} />
        </Svg>
      </Animated.View>
      
      <Animated.View style={[styles.blob, styles.blob3, blob3Style]}>
        <Svg width="180" height="180" viewBox="-100 -100 200 200">
          <Path d={blobPath3} fill={colors[2]} opacity={0.2} />
        </Svg>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    overflow: 'hidden',
  },
  blob: {
    position: 'absolute',
  },
  blob1: {
    top: height * 0.1,
    right: -50,
  },
  blob2: {
    top: height * 0.4,
    left: -30,
  },
  blob3: {
    bottom: height * 0.2,
    right: -40,
  },
});