# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

InnerChyl is an Expo React Native app that transforms user photos into cartoon-style avatars in the "Charlie and Lola" art style, optimized for sharing on Instagram Stories and TikTok.

## Development Commands

```bash
# Start development server
npm start

# Start web development with debugging
npm run start-web-dev

# Run linting
npm run lint
```

## API Configuration

For the pose matching feature to work, you need to configure a Google Gemini API key:

1. Get an API key from: https://makersuite.google.com/app/apikey
2. Add it to `constants/config.ts`:
   ```typescript
   GEMINI_API_KEY: 'your-actual-api-key-here'
   ```
   Or set it as an environment variable:
   ```bash
   EXPO_PUBLIC_GEMINI_API_KEY=your-actual-api-key-here
   ```

## Architecture

### Tech Stack
- **Framework**: Expo SDK 53 with Expo Router for file-based routing
- **State Management**: Zustand for global state, React Query for server state
- **Styling**: NativeWind (Tailwind for React Native) with custom theme constants
- **TypeScript**: Strict mode enabled
- **Package Manager**: npm/bun/yarn

### Project Structure

```
/app/             # Expo Router screens (file-based routing)
  index.tsx       # Splash/landing screen
  upload.tsx      # Photo selection screen
  processing.tsx  # Processing animation screen
  results.tsx     # Final result with share options
  pose-capture.tsx    # Capture user pose for scene creation
  pose-processing.tsx # Analyze pose and generate matching cartoon
  scene-editor.tsx    # Position cartoon twin in scene
  _layout.tsx     # Root layout with navigation stack

/components/      # Reusable UI components
  BlobBackground.tsx  # Animated background component
  WobblyButton.tsx    # Custom animated button

/services/        # API and external service integrations
  api.ts          # API client for image processing (Gemini 2.5 Flash)

/hooks/           # Custom React hooks
  useImagePicker.ts   # Image selection logic

/constants/       # App-wide constants
  theme.ts        # Design tokens (colors, spacing, platform specs)
```

### Key Technical Details

1. **Routing**: Uses Expo Router with Stack navigation. All screens are defined in `/app/` directory.

2. **Image Processing Flow**:
   - Main flow: User selects/captures photo → Upload to API → Generate cartoon via Gemini 2.5 Flash → Display result
   - Scene creation: User uploads pose photo → Gemini analyzes pose → Generate cartoon in same pose → Position in scene
   - API endpoints: 
     - Cartoon generation: Gemini 2.5 Flash Image API
     - Pose analysis: Gemini 2.0 Flash API

3. **Platform Optimization**: Supports specific aspect ratios and sizes for Instagram Story (9:16), Instagram Post (1:1), and TikTok (9:16).

4. **Permissions**: Requires camera and photo library access on both iOS and Android.

5. **Path Aliases**: Uses `@/` prefix for absolute imports from root directory.

6. **Theme System**: Centralized theme in `constants/theme.ts` with bright, playful color palette.

## Important Considerations

- The app uses Google Gemini 2.5 Flash for AI-powered image generation
- Mock implementations exist in `services/api.ts` for features pending backend implementation
- The cartoon generation uses a specific "Charlie and Lola" style prompt for consistency
- React 19 and React Native 0.79.1 are used (latest versions)