# Background Removal Service Configuration

## Current Configuration

The app is configured to use background removal services in `constants/config.ts`:

```typescript
BACKGROUND_REMOVAL_SERVICE: 'REMOVE.BG' // or 'HUGGINGFACE'
```

## Available Services

### 1. REMOVE.BG (Default)
- **Quality**: Best quality background removal
- **Limit**: 50 free images per month
- **Speed**: ~1 second processing
- **API Key**: Required (currently configured)

### 2. HUGGINGFACE
- **Quality**: Good quality background removal  
- **Limit**: UNLIMITED - Completely FREE
- **Speed**: ~2-3 seconds processing
- **API Key**: Not required (optional HF token for priority)

## How to Switch Services

Edit `constants/config.ts` and change the `BACKGROUND_REMOVAL_SERVICE` value:

### To use REMOVE.BG (current setting):
```typescript
BACKGROUND_REMOVAL_SERVICE: 'REMOVE.BG' as 'REMOVE.BG' | 'HUGGINGFACE',
```

### To use HUGGINGFACE (unlimited free):
```typescript
BACKGROUND_REMOVAL_SERVICE: 'HUGGINGFACE' as 'REMOVE.BG' | 'HUGGINGFACE',
```

## Automatic Fallback

The app automatically falls back to the other service if the primary fails:
- If REMOVE.BG is selected but fails (quota exceeded, API down), it uses HUGGINGFACE
- If HUGGINGFACE is selected but fails (service down), it uses REMOVE.BG (if API key configured)

## When to Use Each Service

### Use REMOVE.BG when:
- You need the highest quality results
- Processing speed is critical (~1 second)
- You're under the 50 images/month limit
- Creating final production assets

### Use HUGGINGFACE when:
- You need unlimited processing (testing, development)
- Cost is a concern (100% free)
- You've exceeded Remove.bg quota
- Quality requirements are moderate

## Console Output

The app will log which service is being used:
```
Background removal configured to use: REMOVE.BG (fallback: HUGGINGFACE)
```
or
```
Background removal configured to use: HUGGINGFACE (fallback: REMOVE.BG)
```

## Testing Each Service

You can test each service individually:

### Test Remove.bg:
```bash
node test-removebg.js
```

### Test HuggingFace:
```bash
node test-huggingface.js
```

## Environment Variables

Both services can be configured via environment variables in `.env.local`:

```bash
# Remove.bg API Key (required for REMOVE.BG service)
EXPO_PUBLIC_REMOVE_BG_API_KEY=qaxYVvtnBz7omyNaVHRJcdyZ

# Optional: HuggingFace token for priority queue (not required)
# EXPO_PUBLIC_HF_TOKEN=hf_xxxxxxxxxxxxx
```