import { config } from '@/constants/config';
import * as FileSystem from 'expo-file-system';

// Helper function for HuggingFace background removal (FREE fallback)
async function removeBackgroundHuggingFace(base64Image: string): Promise<string> {
  try {
    console.log('🤗 Using HuggingFace for background removal...');
    console.log('✨ HuggingFace: FREE unlimited usage, good quality');
    
    // Convert base64 to data URL for HF API
    const imageDataUrl = `data:image/png;base64,${base64Image}`;
    
    // Step 1: Submit image for processing with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
    
    const response = await fetch(config.HUGGINGFACE_BG_REMOVAL_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(config.HF_TOKEN ? { 'Authorization': `Bearer ${config.HF_TOKEN}` } : {})
      },
      body: JSON.stringify({ data: [imageDataUrl] }),
      signal: controller.signal
    });
    
    clearTimeout(timeoutId);
    
    if (!response.ok) {
      throw new Error(`HuggingFace API error: ${response.status}`);
    }
    
    const { event_id } = await response.json();
    
    // Step 2: Fetch results with polling
    let attempts = 0;
    const maxAttempts = 10;
    
    while (attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 1000)); // Wait 1 second
      
      const resultController = new AbortController();
      const resultTimeoutId = setTimeout(() => resultController.abort(), 5000); // 5 second timeout per poll
      
      const resultResponse = await fetch(
        `${config.HUGGINGFACE_BG_REMOVAL_URL}/${event_id}`,
        { signal: resultController.signal }
      );
      
      clearTimeout(resultTimeoutId);
      
      if (resultResponse.ok) {
        const resultText = await resultResponse.text();
        
        // Parse Server-Sent Events format
        const lines = resultText.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const jsonData = JSON.parse(line.substring(6));
              // Check for result in different possible formats
              if (jsonData?.[0]?.[1]?.url) {
                // Download the processed image and convert to base64
                const processedResponse = await fetch(jsonData[0][1].url);
                const blob = await processedResponse.blob();
                return new Promise<string>((resolve) => {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    const result = reader.result as string;
                    resolve(result); // Returns full data URL
                  };
                  reader.readAsDataURL(blob);
                });
              } else if (jsonData?.[0]?.url) {
                // Alternative response format
                const processedResponse = await fetch(jsonData[0].url);
                const blob = await processedResponse.blob();
                return new Promise<string>((resolve) => {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    const result = reader.result as string;
                    resolve(result);
                  };
                  reader.readAsDataURL(blob);
                });
              }
            } catch (parseError) {
              // Continue to next line if parsing fails
            }
          }
        }
      }
      
      attempts++;
    }
    
    throw new Error('HuggingFace processing timeout');
  } catch (error) {
    console.error('HuggingFace background removal failed:', error);
    throw error;
  }
}

// Helper function for Remove.bg API
async function removeBackgroundRemoveBg(base64Image: string): Promise<string> {
  console.log('🎨 Using Remove.bg API for background removal...');
  console.log('📊 Remove.bg: Premium quality, 50 free/month');
  
  const removeBgResponse = await fetch(config.REMOVE_BG_API_URL, {
    method: 'POST',
    headers: {
      'X-Api-Key': config.REMOVE_BG_API_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      image_file_b64: base64Image,
      size: 'auto',
      format: 'png',
    }),
  });
  
  if (!removeBgResponse.ok) {
    const errorText = await removeBgResponse.text();
    throw new Error(`Remove.bg API failed: ${errorText}`);
  }
  
  const removeBgBlob = await removeBgResponse.blob();
  return new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      resolve(result);
    };
    reader.readAsDataURL(removeBgBlob);
  });
}

// Helper function to remove background with configurable service and fallback
async function removeBackgroundWithFallback(base64Image: string): Promise<string> {
  const primaryService = config.BACKGROUND_REMOVAL_SERVICE;
  
  console.log('═══════════════════════════════════════════');
  console.log(`🔧 BACKGROUND REMOVAL SERVICE: ${primaryService}`);
  console.log('═══════════════════════════════════════════');
  
  // Check if background removal is disabled
  if (primaryService === 'NONE') {
    console.log('⏭️ Background removal skipped (NONE selected)');
    return `data:image/png;base64,${base64Image}`;
  }
  
  const fallbackService = primaryService === 'REMOVE.BG' ? 'HUGGINGFACE' : 'REMOVE.BG';
  console.log(`🔄 Fallback service: ${fallbackService}`);
  
  // Try primary service first
  try {
    if (primaryService === 'REMOVE.BG') {
      // Check if API key is configured
      if (!config.REMOVE_BG_API_KEY || config.REMOVE_BG_API_KEY === 'YOUR_API_KEY_HERE') {
        throw new Error('Remove.bg API key not configured');
      }
      const result = await removeBackgroundRemoveBg(base64Image);
      console.log('✅ Remove.bg: Background removed successfully!');
      return result;
    } else if (primaryService === 'HUGGINGFACE') {
      const result = await removeBackgroundHuggingFace(base64Image);
      console.log('✅ HuggingFace: Background removed successfully!');
      return result;
    }
  } catch (error) {
    console.warn(`⚠️ ${primaryService} failed, switching to fallback ${fallbackService}`);
    console.log(`❌ Error details: ${error.message}`);
    
    // Try fallback service
    try {
      if (fallbackService === 'REMOVE.BG') {
        // Check if API key is configured for fallback
        if (!config.REMOVE_BG_API_KEY || config.REMOVE_BG_API_KEY === 'YOUR_API_KEY_HERE') {
          throw new Error('Remove.bg API key not configured for fallback');
        }
        const result = await removeBackgroundRemoveBg(base64Image);
        console.log('✅ Remove.bg (fallback): Background removed successfully!');
        return result;
      } else {
        const result = await removeBackgroundHuggingFace(base64Image);
        console.log('✅ HuggingFace (fallback): Background removed successfully!');
        return result;
      }
    } catch (fallbackError) {
      console.error(`❌ Both ${primaryService} and ${fallbackService} failed!`);
      console.error('Error details:', fallbackError.message);
      throw new Error('All background removal services failed');
    }
  }
}

export interface CartoonGenerationResult {
  cartoonImageUrl: string;
  compositeImageUrl: string;
}

export interface ShareData {
  formattedUrl: string;
  caption: string;
}

export interface PoseAnalysisResult {
  poseDescription: string;
  cartoonInPoseUrl: string;
}

export interface OneStepCartoonResult {
  cartoonUrl: string;
  poseDescription: string;
  originalUrl: string;
}

export const API = {
  uploadImage: async (imageUri: string): Promise<{ uploadId: string; processUrl: string }> => {
    // For now, return mock data - backend team will implement actual upload
    return {
      uploadId: `upload_${Date.now()}`,
      processUrl: imageUri
    };
  },

  generateCartoon: async (uploadId: string, imageUri: string): Promise<CartoonGenerationResult> => {
    try {
      // Convert image to base64
      let base64: string;
      
      if (imageUri.startsWith('file://')) {
        // Use Expo FileSystem for local files
        const decodedUri = decodeURIComponent(imageUri);
        base64 = await FileSystem.readAsStringAsync(decodedUri, {
          encoding: FileSystem.EncodingType.Base64,
        });
      } else if (imageUri.startsWith('data:')) {
        // If it's already a data URI, extract the base64
        base64 = imageUri.split(',')[1];
      } else {
        // Handle regular HTTP URLs
        const response = await fetch(imageUri);
        const blob = await response.blob();
        base64 = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const result = reader.result as string;
            resolve(result.split(',')[1]);
          };
          reader.readAsDataURL(blob);
        });
      }

      // Generate cartoon using Gemini 2.5 Flash Image (Nano Banana)
      console.log('Using Gemini 2.5 Flash Image for cartoon generation...');
      const cartoonResponse = await fetch(`${config.GEMINI_IMAGE_API_URL}?key=${config.GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [{
            parts: [
              {
                text: `Transform this person into a Charlie and Lola style cartoon character. Create a whimsical, hand-drawn cartoon with:
- Thin, sketchy black outlines with slight wobble
- Completely flat colors with no gradients
- Simple childlike proportions with slightly oversized head
- Minimal facial features (dots for eyes, simple lines for nose and mouth)
- Playful, imperfect hand-drawn charm
- Small texture lines for hair and fabric details
- Transparent background (no background elements)`
              },
              {
                inlineData: {
                  mimeType: "image/jpeg",
                  data: base64
                }
              }
            ]
          }],
          generationConfig: {
            temperature: 0.9,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 8192
          }
        }),
      });

      if (!cartoonResponse.ok) {
        const errorData = await cartoonResponse.json();
        console.error('Gemini API error:', errorData);
        throw new Error('Failed to generate cartoon description');
      }

      const cartoonData = await cartoonResponse.json();
      console.log('Response structure:', JSON.stringify(cartoonData, null, 2).substring(0, 500));
      
      // Extract the generated image from Gemini's response
      if (!cartoonData.candidates || !cartoonData.candidates[0]) {
        throw new Error('No image generated from Gemini');
      }
      
      const candidate = cartoonData.candidates[0];
      let cartoonImageUrl: string;
      
      // Look for image data in ANY part of the response
      if (candidate.content && candidate.content.parts && candidate.content.parts.length > 0) {
        // Find the part with image data
        const imagePart = candidate.content.parts.find(part => part.inlineData);
        
        if (imagePart && imagePart.inlineData) {
          // Image is returned as inline data
          console.log('✅ Cartoon generated successfully!');
          cartoonImageUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
        } else {
          // No image found, check for text response
          const textPart = candidate.content.parts.find(part => part.text);
          if (textPart) {
            console.warn('⚠️ Gemini returned only text, no image generated');
            console.log('Response text:', textPart.text.substring(0, 200));
            
            // Create a temporary placeholder
            const placeholderSvg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
              <rect width="512" height="512" fill="#FFE4E1"/>
              <text x="256" y="256" font-family="Arial" font-size="20" text-anchor="middle" fill="#333">
                Cartoon Generation (Text Mode)
              </text>
            </svg>`;
            cartoonImageUrl = `data:image/svg+xml;base64,${btoa(placeholderSvg)}`;
          } else {
            throw new Error('No content in response');
          }
        }
      } else {
        console.error('Unexpected response structure:', JSON.stringify(cartoonData, null, 2));
        throw new Error('Invalid response structure from Gemini');
      }

      // Process through background removal if we have an actual image (not SVG)
      const isSvg = cartoonImageUrl.startsWith('data:image/svg');
      if (cartoonImageUrl.startsWith('data:image') && !isSvg) {
        try {
          // Extract base64 from data URL
          const base64Image = cartoonImageUrl.split(',')[1];
          
          // Validate that we have actual base64 data
          if (base64Image && base64Image.length > 100) {
            console.log('Processing background removal...');
            console.log('Base64 data length:', base64Image.length);
            const processedImage = await removeBackgroundWithFallback(base64Image);
            console.log('Background removed successfully!');
            
            return {
              cartoonImageUrl: processedImage,
              compositeImageUrl: processedImage
            };
          } else {
            console.log('Invalid or empty base64 data, skipping background removal');
            return {
              cartoonImageUrl,
              compositeImageUrl: cartoonImageUrl
            };
          }
        } catch (error) {
          console.error('Background removal failed, using original:', error);
          // Fall back to original if background removal fails
          return {
            cartoonImageUrl,
            compositeImageUrl: cartoonImageUrl
          };
        }
      }
      
      // If it's not an image (e.g., SVG placeholder), return as is
      return {
        cartoonImageUrl,
        compositeImageUrl: cartoonImageUrl
      };
    } catch (error) {
      console.error('Error generating cartoon:', error);
      throw new Error('Failed to generate cartoon. Please try again!');
    }
  },

  formatForPlatform: async (imageUrl: string, platform: 'instagram-story' | 'instagram-post' | 'tiktok'): Promise<ShareData> => {
    // Mock implementation - backend will handle actual formatting
    const captions = {
      'instagram-story': 'Just found my cartoon twin! 🎨✨ #innerchyl #cartoonme',
      'instagram-post': 'Meet my cartoon double! Created with innerchyl 🎨 #cartoonart #digitalart #innerchyl',
      'tiktok': 'POV: You found your cartoon twin 🎨✨ #innerchyl #cartoonfilter #transformation'
    };

    return {
      formattedUrl: imageUrl,
      caption: captions[platform]
    };
  },

  // Single-step function that creates cartoon matching both appearance and pose
  generateCartoonWithPose: async (imageUri: string): Promise<OneStepCartoonResult> => {
    try {
      console.log('=== Starting generateCartoonWithPose ===');
      console.log('Image URI:', imageUri);
      
      // Check if Gemini API key is configured
      if (!config.GEMINI_API_KEY || config.GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
        throw new Error('Please configure your Gemini API key:\n1. Copy .env.example to .env\n2. Add your API key: EXPO_PUBLIC_GEMINI_API_KEY=your-key-here\n3. Restart the Expo development server');
      }

      // Convert image to base64
      console.log('Step 1: Converting image to base64...');
      let base64: string;
      
      try {
        // For React Native, we need to handle file:// URIs differently
        if (imageUri.startsWith('file://')) {
          // Use Expo FileSystem for local files
          console.log('Reading local file with FileSystem...');
          // Decode the URI to handle special characters like @ and spaces
          const decodedUri = decodeURIComponent(imageUri);
          console.log('Decoded URI:', decodedUri);
          base64 = await FileSystem.readAsStringAsync(decodedUri, {
            encoding: FileSystem.EncodingType.Base64,
          });
          console.log('File read successfully, base64 length:', base64.length);
        } else if (imageUri.startsWith('data:')) {
          // If it's already a data URI, extract the base64
          base64 = imageUri.split(',')[1];
          console.log('Using existing data URI, base64 length:', base64.length);
        } else {
          // Handle regular HTTP URLs
          const response = await fetch(imageUri);
          if (!response.ok) {
            throw new Error(`Failed to fetch image: ${response.status}`);
          }
          const blob = await response.blob();
          console.log('Image blob size:', blob.size, 'bytes');
          
          base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = reader.result as string;
              resolve(result.split(',')[1]);
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        }
        console.log('Image converted to base64, length:', base64.length);
      } catch (fetchError) {
        console.error('Failed to load image:', fetchError);
        console.error('Image URI that failed:', imageUri);
        throw new Error(`Unable to load image: ${fetchError.message}`);
      }

      // Step 1: Analyze pose with Gemini
      console.log('Step 2: Analyzing pose with Gemini API...');
      console.log('Gemini URL:', `${config.GEMINI_API_URL}?key=${config.GEMINI_API_KEY.substring(0, 10)}...`);
      
      let geminiResponse;
      try {
        geminiResponse = await fetch(`${config.GEMINI_API_URL}?key=${config.GEMINI_API_KEY}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [{
              parts: [
                {
                  text: "Analyze this image and describe the person's pose in detail. Focus on: body position, arm positions, leg positions, head angle, and any specific gestures. Be very specific about angles and positions."
                },
                {
                  inlineData: {
                    mimeType: "image/jpeg",
                    data: base64
                  }
                }
              ]
            }]
          })
        });
      } catch (fetchError) {
        console.error('Network error calling Gemini API:', fetchError);
        throw new Error(`Network error: Unable to connect to Gemini API. ${fetchError.message}`);
      }

      if (!geminiResponse.ok) {
        const errorData = await geminiResponse.json();
        console.error('Gemini API error response:', errorData);
        throw new Error(`Gemini API failed (${geminiResponse.status}): ${JSON.stringify(errorData)}`);
      }

      const geminiData = await geminiResponse.json();
      console.log('Gemini response received');
      
      if (!geminiData.candidates || !geminiData.candidates[0]) {
        console.error('Invalid Gemini response structure:', geminiData);
        throw new Error('Invalid response from Gemini API');
      }
      
      const poseDescription = geminiData.candidates[0].content.parts[0].text;
      console.log('Pose description:', poseDescription.substring(0, 100) + '...');

      // Step 2: Generate cartoon in the analyzed pose with Gemini 2.5 Flash Image
      console.log('Step 3: Generating cartoon with Gemini 2.5 Flash Image...');
      console.log('Gemini URL:', config.GEMINI_IMAGE_API_URL);
      
      let cartoonResponse;
      try {
        cartoonResponse = await fetch(`${config.GEMINI_IMAGE_API_URL}?key=${config.GEMINI_API_KEY}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [{
              parts: [
                {
                  text: `Generate a Charlie and Lola style cartoon character. The character must be in this exact pose: ${poseDescription}

STYLE:
- Thin, sketchy black outlines with hand-drawn wobble
- Completely flat colors, no gradients or shading
- Simple childlike proportions, slightly oversized head
- Minimal facial features (dots for eyes, simple lines for nose/mouth)
- Playful, imperfect hand-drawn charm
- Small texture lines for hair and fabric

REQUIREMENTS:
- Match the person's appearance and clothing
- Maintain the exact pose described
- Transparent background (no background elements)
- Keep any facial hair as simple sketch lines
- Preserve skin tone as flat color
- Minimal cartoon-like accessories`
                },
                {
                  inlineData: {
                    mimeType: "image/jpeg",
                    data: base64
                  }
                }
              ]
            }],
            generationConfig: {
              temperature: 0.9,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: 8192
            }
          }),
        });
      } catch (fetchError) {
        console.error('Network error calling Gemini API:', fetchError);
        throw new Error(`Network error: Unable to connect to Gemini API. ${fetchError.message}`);
      }

      if (!cartoonResponse.ok) {
        const errorText = await cartoonResponse.text();
        console.error('Gemini API error response:', errorText);
        throw new Error(`Gemini API failed (${cartoonResponse.status}): ${errorText}`);
      }

      const cartoonData = await cartoonResponse.json();
      console.log('Gemini 2.5 Flash Image response received successfully');
      console.log('Response structure:', JSON.stringify(cartoonData, null, 2).substring(0, 500));
      
      // Log what type of content we received
      if (cartoonData.candidates?.[0]?.content?.parts) {
        const parts = cartoonData.candidates[0].content.parts;
        console.log(`Received ${parts.length} parts in response`);
        parts.forEach((part, index) => {
          if (part.inlineData) {
            console.log(`✅ Part ${index}: Image data`);
            console.log('  Image mime type:', part.inlineData.mimeType);
            console.log('  Image data length:', part.inlineData.data?.length || 0);
          } else if (part.text) {
            console.log(`📝 Part ${index}: Text`);
            console.log('  Text preview:', part.text.substring(0, 100));
          }
        });
      }
      
      // Extract the generated image from response
      if (!cartoonData.candidates || !cartoonData.candidates[0]) {
        throw new Error('No image generated from Gemini');
      }
      
      const candidate = cartoonData.candidates[0];
      let cartoonUrl: string;
      
      // Look for image data in ANY part of the response
      if (candidate.content && candidate.content.parts && candidate.content.parts.length > 0) {
        // Find the part with image data
        const imagePart = candidate.content.parts.find(part => part.inlineData);
        
        if (imagePart && imagePart.inlineData) {
          // Image is returned as inline data
          console.log('✅ Cartoon generated successfully with pose!');
          cartoonUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
        } else {
          // No image found, check for text response
          const textPart = candidate.content.parts.find(part => part.text);
          if (textPart) {
            console.warn('⚠️ Gemini returned only text, no image generated');
            console.log('Response text:', textPart.text.substring(0, 200));
            
            // Create a temporary placeholder
            const placeholderSvg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
              <rect width="512" height="512" fill="#FFE4E1"/>
              <text x="256" y="256" font-family="Arial" font-size="20" text-anchor="middle" fill="#333">
                Image generation in progress
              </text>
            </svg>`;
            cartoonUrl = `data:image/svg+xml;base64,${btoa(placeholderSvg)}`;
          } else {
            throw new Error('No content in response');
          }
        }
      } else {
        console.error('Unexpected response structure:', JSON.stringify(cartoonData, null, 2));
        throw new Error('Invalid response structure from Gemini');
      }
      
      console.log('Step 4: Cartoon with pose generated successfully');
      
      // Process through background removal if we have an actual image (not SVG)
      let finalCartoonUrl = cartoonUrl;
      // Check mime type properly - only check the mime type part, not the base64 data
      const isSvg = cartoonUrl && cartoonUrl.startsWith('data:image/svg');
      const isValidImage = cartoonUrl && cartoonUrl.startsWith('data:image') && !isSvg;
      
      if (isValidImage) {
        try {
          // Extract base64 from data URL
          const cartoonBase64 = cartoonUrl.split(',')[1];
          
          // Validate that we have actual base64 data
          if (cartoonBase64 && cartoonBase64.length > 100) {
            console.log('Step 5: Processing background removal...');
            console.log('Base64 data length:', cartoonBase64.length);
            const processedImage = await removeBackgroundWithFallback(cartoonBase64);
            console.log('Background removed successfully!');
            finalCartoonUrl = processedImage;
          } else {
            console.log('Invalid or empty base64 data, skipping background removal');
          }
        } catch (error) {
          console.error('Background removal failed, using original:', error);
          // Keep the original if background removal fails
        }
      } else {
        console.log('Not a valid image format for background removal, skipping');
      }
      
      // Convert original image to base64 data URI for consistent cross-platform support
      const originalDataUrl = `data:image/jpeg;base64,${base64}`;

      console.log('=== Cartoon generation completed successfully ===');
      return {
        cartoonUrl: finalCartoonUrl,
        poseDescription,
        originalUrl: originalDataUrl
      };
    } catch (error) {
      console.error('Error generating cartoon with pose:', error);
      console.error('Error details:', {
        message: error.message,
        name: error.name,
        stack: error.stack
      });
      
      // Provide more specific error messages
      if (error.message.includes('Network error')) {
        throw new Error('Network connection issue. Please check your internet connection and try again.');
      } else if (error.message.includes('Gemini API')) {
        throw new Error('Issue with pose analysis. Please check your Gemini API key configuration.');
      } else if (error.message.includes('cartoon generation')) {
        throw new Error('Issue with cartoon generation service. Please try again later.');
      } else if (error.message.includes('Unable to load image')) {
        throw new Error('Unable to load the selected image. Please try again.');
      }
      
      throw new Error('Failed to generate cartoon. Please try again!');
    }
  },

  generateCartoonInPose: async (cartoonUri: string, poseImageUri: string): Promise<PoseAnalysisResult> => {
    try {
      console.log('Starting generateCartoonInPose...');
      console.log('Cartoon URI:', cartoonUri);
      console.log('Pose Image URI:', poseImageUri);
      
      // Check if Gemini API key is configured
      if (!config.GEMINI_API_KEY || config.GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
        throw new Error('Please configure your Gemini API key:\n1. Copy .env.example to .env\n2. Add your API key: EXPO_PUBLIC_GEMINI_API_KEY=your-key-here\n3. Restart the Expo development server');
      }

      // Step 1: Analyze pose with Gemini 2.0 Flash
      console.log('Step 1: Converting pose image to base64...');
      let poseBase64: string;
      
      if (poseImageUri.startsWith('file://')) {
        // Use Expo FileSystem for local files
        console.log('Reading local pose file with FileSystem...');
        // Decode the URI to handle special characters like @ and spaces
        const decodedUri = decodeURIComponent(poseImageUri);
        poseBase64 = await FileSystem.readAsStringAsync(decodedUri, {
          encoding: FileSystem.EncodingType.Base64,
        });
      } else if (poseImageUri.startsWith('data:')) {
        // If it's already a data URI, extract the base64
        poseBase64 = poseImageUri.split(',')[1];
      } else {
        // Handle regular HTTP URLs
        const poseResponse = await fetch(poseImageUri);
        if (!poseResponse.ok) {
          throw new Error(`Failed to fetch pose image: ${poseResponse.status}`);
        }
        const poseBlob = await poseResponse.blob();
        poseBase64 = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const result = reader.result as string;
            resolve(result.split(',')[1]);
          };
          reader.readAsDataURL(poseBlob);
        });
      }
      console.log('Pose image converted to base64 successfully');

      // Use Gemini to analyze the pose
      console.log('Step 2: Calling Gemini API to analyze pose...');
      console.log('Gemini API URL:', `${config.GEMINI_API_URL}?key=${config.GEMINI_API_KEY.substring(0, 10)}...`);
      
      let geminiResponse;
      try {
        geminiResponse = await fetch(`${config.GEMINI_API_URL}?key=${config.GEMINI_API_KEY}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [{
              parts: [
                {
                  text: "Analyze this image and describe the person's pose in detail. Focus on: body position, arm positions, leg positions, head angle, and any specific gestures. Be very specific about angles and positions."
                },
                {
                  inlineData: {
                    mimeType: "image/jpeg",
                    data: poseBase64
                  }
                }
              ]
            }]
          })
        });
      } catch (fetchError) {
        console.error('Network error calling Gemini API:', fetchError);
        throw new Error(`Network error: Unable to connect to Gemini API. ${fetchError.message}`);
      }

      if (!geminiResponse.ok) {
        const errorData = await geminiResponse.json();
        console.error('Gemini API error response:', errorData);
        throw new Error(`Gemini API failed (${geminiResponse.status}): ${JSON.stringify(errorData)}`);
      }

      const geminiData = await geminiResponse.json();
      console.log('Gemini API response received');
      
      if (!geminiData.candidates || !geminiData.candidates[0]) {
        console.error('Invalid Gemini response structure:', geminiData);
        throw new Error('Invalid response from Gemini API');
      }
      
      const poseDescription = geminiData.candidates[0].content.parts[0].text;
      console.log('Pose description extracted:', poseDescription.substring(0, 100) + '...');

      // Step 2: Get cartoon base64
      console.log('Step 3: Converting cartoon image to base64...');
      let cartoonBase64: string;
      
      if (cartoonUri.startsWith('file://')) {
        // Use Expo FileSystem for local files
        console.log('Reading local cartoon file with FileSystem...');
        // Decode the URI to handle special characters like @ and spaces
        const decodedUri = decodeURIComponent(cartoonUri);
        cartoonBase64 = await FileSystem.readAsStringAsync(decodedUri, {
          encoding: FileSystem.EncodingType.Base64,
        });
      } else if (cartoonUri.startsWith('data:')) {
        // If it's already a data URI, extract the base64
        cartoonBase64 = cartoonUri.split(',')[1];
      } else {
        // Handle regular HTTP URLs
        const cartoonResponse = await fetch(cartoonUri);
        if (!cartoonResponse.ok) {
          throw new Error(`Failed to fetch cartoon image: ${cartoonResponse.status}`);
        }
        const cartoonBlob = await cartoonResponse.blob();
        cartoonBase64 = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onloadend = () => {
            const result = reader.result as string;
            resolve(result.split(',')[1]);
          };
          reader.readAsDataURL(cartoonBlob);
        });
      }
      console.log('Cartoon image converted to base64 successfully');

      // Step 3: Generate cartoon in the same pose using Gemini 2.5 Flash Image
      console.log('Step 4: Generating cartoon in pose with Gemini 2.5 Flash Image...');
      console.log('Gemini API URL:', config.GEMINI_IMAGE_API_URL);
      
      let cartoonInPoseResponse;
      try {
        cartoonInPoseResponse = await fetch(`${config.GEMINI_IMAGE_API_URL}?key=${config.GEMINI_API_KEY}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [{
              parts: [
                {
                  text: `Recreate this Charlie and Lola style cartoon character in the following pose: ${poseDescription}
            
IMPORTANT: 
- Keep the exact same cartoon character design and colors
- Only change the pose to match the description
- Maintain the thin sketchy outlines and flat colors
- Keep the same clothing and features
- Match all body, arm, leg, and head positions exactly
- Transparent background`
                },
                {
                  inlineData: {
                    mimeType: "image/jpeg",
                    data: cartoonBase64
                  }
                }
              ]
            }],
            generationConfig: {
              temperature: 0.9,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: 8192
            }
          }),
        });
      } catch (fetchError) {
        console.error('Network error calling Gemini API:', fetchError);
        throw new Error(`Network error: Unable to connect to Gemini API. ${fetchError.message}`);
      }

      if (!cartoonInPoseResponse.ok) {
        const errorText = await cartoonInPoseResponse.text();
        console.error('Gemini API error response:', errorText);
        throw new Error(`Gemini API failed (${cartoonInPoseResponse.status}): ${errorText}`);
      }

      const cartoonInPoseData = await cartoonInPoseResponse.json();
      console.log('Gemini 2.5 Flash Image response received successfully');
      console.log('Response structure:', JSON.stringify(cartoonInPoseData, null, 2).substring(0, 500));
      
      // Extract the generated image from response
      if (!cartoonInPoseData.candidates || !cartoonInPoseData.candidates[0]) {
        throw new Error('No image generated from Gemini');
      }
      
      const candidate = cartoonInPoseData.candidates[0];
      let cartoonInPoseUrl: string;
      
      // Look for image data in ANY part of the response
      if (candidate.content && candidate.content.parts && candidate.content.parts.length > 0) {
        // Find the part with image data
        const imagePart = candidate.content.parts.find(part => part.inlineData);
        
        if (imagePart && imagePart.inlineData) {
          // Image is returned as inline data
          console.log('✅ Cartoon in new pose generated successfully!');
          cartoonInPoseUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
        } else {
          // No image found, check for text response
          const textPart = candidate.content.parts.find(part => part.text);
          if (textPart) {
            console.warn('⚠️ Gemini returned only text, no image generated');
            console.log('Response text:', textPart.text.substring(0, 200));
            
            // Create a temporary placeholder
            const placeholderSvg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
              <rect width="512" height="512" fill="#E6F3FF"/>
              <text x="256" y="256" font-family="Arial" font-size="20" text-anchor="middle" fill="#333">
                Pose Analysis (Text Mode)
              </text>
            </svg>`;
            cartoonInPoseUrl = `data:image/svg+xml;base64,${btoa(placeholderSvg)}`;
          } else {
            throw new Error('No content in response');
          }
        }
      } else {
        console.error('Unexpected response structure:', JSON.stringify(cartoonInPoseData, null, 2));
        throw new Error('Invalid response structure from Gemini');
      }

      // Process through background removal if we have an actual image (not SVG)
      let finalCartoonUrl = cartoonInPoseUrl;
      const isSvg = cartoonInPoseUrl.startsWith('data:image/svg');
      if (cartoonInPoseUrl.startsWith('data:image') && !isSvg) {
        try {
          // Extract base64 from data URL  
          const cartoonBase64 = cartoonInPoseUrl.split(',')[1];
          
          // Validate that we have actual base64 data
          if (cartoonBase64 && cartoonBase64.length > 100) {
            console.log('Processing background removal...');
            console.log('Base64 data length:', cartoonBase64.length);
            const processedImage = await removeBackgroundWithFallback(cartoonBase64);
            console.log('Background removed successfully!');
            finalCartoonUrl = processedImage;
          } else {
            console.log('Invalid or empty base64 data, skipping background removal');
          }
        } catch (error) {
          console.error('Background removal failed, using original:', error);
          // Keep the original if background removal fails
        }
      } else {
        console.log('Not a valid image format for background removal, skipping');
      }
      
      console.log('Cartoon in pose generated successfully!');
      return {
        poseDescription,
        cartoonInPoseUrl: finalCartoonUrl
      };
    } catch (error) {
      console.error('Error generating cartoon in pose:', error);
      console.error('Error details:', {
        message: error.message,
        name: error.name,
        stack: error.stack
      });
      
      // Provide more specific error messages
      if (error.message.includes('Network request failed')) {
        throw new Error('Network connection issue. Please check your internet connection and try again.');
      } else if (error.message.includes('Gemini API')) {
        throw new Error('Issue with pose analysis. Please check your Gemini API key configuration.');
      } else if (error.message.includes('cartoon generation')) {
        throw new Error('Issue with cartoon generation service. Please try again later.');
      } else if (error.message.includes('Failed to fetch')) {
        throw new Error('Unable to load images. Please try again.');
      }
      
      throw new Error('Failed to generate cartoon in pose. Please try again!');
    }
  }
};