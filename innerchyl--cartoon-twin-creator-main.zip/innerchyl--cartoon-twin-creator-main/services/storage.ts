import AsyncStorage from '@react-native-async-storage/async-storage';

export interface SavedScene {
  id: string;
  imageUri: string;
  timestamp: number;
  caption?: string;
}

const STORAGE_KEY = 'saved_scenes';

export const StorageService = {
  // Save a new scene to storage
  saveScene: async (imageUri: string, caption?: string): Promise<SavedScene> => {
    try {
      const scene: SavedScene = {
        id: `scene_${Date.now()}`,
        imageUri,
        timestamp: Date.now(),
        caption,
      };

      const existingScenes = await StorageService.getAllScenes();
      const updatedScenes = [scene, ...existingScenes]; // Add new scene at the beginning
      
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedScenes));
      
      return scene;
    } catch (error) {
      console.error('Error saving scene:', error);
      throw error;
    }
  },

  // Get all saved scenes
  getAllScenes: async (): Promise<SavedScene[]> => {
    try {
      const scenesJson = await AsyncStorage.getItem(STORAGE_KEY);
      return scenesJson ? JSON.parse(scenesJson) : [];
    } catch (error) {
      console.error('Error getting scenes:', error);
      return [];
    }
  },

  // Delete a scene
  deleteScene: async (sceneId: string): Promise<void> => {
    try {
      const scenes = await StorageService.getAllScenes();
      const updatedScenes = scenes.filter(scene => scene.id !== sceneId);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedScenes));
    } catch (error) {
      console.error('Error deleting scene:', error);
      throw error;
    }
  },

  // Clear all scenes
  clearAllScenes: async (): Promise<void> => {
    try {
      await AsyncStorage.removeItem(STORAGE_KEY);
    } catch (error) {
      console.error('Error clearing scenes:', error);
      throw error;
    }
  },
};