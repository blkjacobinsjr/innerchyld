import React, { useState, useRef } from 'react';
import { View, Text, StyleSheet, Image, Alert, ScrollView, Dimensions, TouchableOpacity, Platform, PanResponder } from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import * as MediaLibrary from 'expo-media-library';
import * as Sharing from 'expo-sharing';
import ViewShot from 'react-native-view-shot';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
  withSequence,
  withDelay,
  runOnJS
} from 'react-native-reanimated';
import { Move, ZoomIn, ZoomOut, RotateCw, Download, RefreshCw, Share2 } from 'lucide-react-native';
import BlobBackground from '@/components/BlobBackground';
import WobblyButton from '@/components/WobblyButton';
import { theme } from '@/constants/theme';
import { StorageService } from '@/services/storage';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const CANVAS_HEIGHT = SCREEN_WIDTH * 1.3; // Portrait orientation

export default function SceneEditorScreen() {
  const { cartoonInPoseUri, backgroundUri, poseDescription } = useLocalSearchParams<{ 
    cartoonInPoseUri: string;
    backgroundUri: string;
    poseDescription: string;
  }>();
  
  const viewShotRef = useRef<ViewShot>(null);
  const [isSaving, setIsSaving] = useState(false);
  
  // Animated values for cartoon positioning
  const translateX = useSharedValue(SCREEN_WIDTH / 2 - 75);
  const translateY = useSharedValue(CANVAS_HEIGHT / 2 - 100);
  const scale = useSharedValue(1);
  const rotation = useSharedValue(0);

  // Reveal animation values - start from center with smaller scale and faded
  const revealScale = useSharedValue(0.3);
  const revealOpacity = useSharedValue(0);
  const revealRotation = useSharedValue(-10);

  // Sparkle effect values
  const sparkleOpacity = useSharedValue(0);
  const sparkleScale = useSharedValue(0.5);

  // Trigger reveal animation on mount
  React.useEffect(() => {
    // Main reveal animation with spring physics
    revealScale.value = withSpring(1, {
      damping: 12,
      stiffness: 100,
      mass: 1,
      overshootClamping: false,
      restDisplacementThreshold: 0.01,
      restSpeedThreshold: 2,
    });

    revealOpacity.value = withTiming(1, { duration: 400 });

    revealRotation.value = withSpring(0, {
      damping: 15,
      stiffness: 120,
    });

    // Sparkle effect with delay
    setTimeout(() => {
      sparkleOpacity.value = withSequence(
        withTiming(1, { duration: 200 }),
        withDelay(800, withTiming(0, { duration: 600 }))
      );

      sparkleScale.value = withSequence(
        withTiming(1.2, { duration: 200 }),
        withDelay(800, withTiming(0, { duration: 600 }))
      );
    }, 300);
  }, []);

  const handleReset = () => {
    translateX.value = withSpring(SCREEN_WIDTH / 2 - 75);
    translateY.value = withSpring(CANVAS_HEIGHT / 2 - 100);
    scale.value = withSpring(1);
    rotation.value = withSpring(0);
  };

  const handleZoomIn = () => {
    scale.value = withSpring(Math.min(scale.value * 1.2, 3));
  };

  const handleZoomOut = () => {
    scale.value = withSpring(Math.max(scale.value * 0.8, 0.5));
  };

  const handleRotate = () => {
    rotation.value = withSpring(rotation.value + 45);
  };

  const handleSaveScene = async () => {
    try {
      setIsSaving(true);
      
      if (!viewShotRef.current?.capture) {
        throw new Error('Unable to capture view');
      }

      const uri = await viewShotRef.current.capture();
      
      // Save to gallery
      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'We need permission to save to your gallery');
        return;
      }

      await MediaLibrary.saveToLibraryAsync(uri);
      
      // Save to app storage for gallery
      await StorageService.saveScene(uri);
      
      Alert.alert(
        'Saved! 🎉', 
        'Your cartoon scene has been saved!',
        [
          { text: 'Share', onPress: () => handleShare(uri) },
          { text: 'View Gallery', onPress: () => router.push('/gallery') },
          { text: 'Create Another', onPress: () => router.push('/upload') },
          { text: 'Done', onPress: () => router.push('/') }
        ]
      );
    } catch (error) {
      console.error('Error saving scene:', error);
      Alert.alert('Error', 'Failed to save scene');
    } finally {
      setIsSaving(false);
    }
  };

  const handleShare = async (uri: string) => {
    try {
      const isAvailable = await Sharing.isAvailableAsync();
      if (isAvailable) {
        await Sharing.shareAsync(uri, {
          dialogTitle: 'Share your cartoon twin!',
          mimeType: 'image/png',
        });
      } else {
        Alert.alert('Sharing not available', 'Sharing is not available on this device');
      }
    } catch (error) {
      console.error('Error sharing:', error);
      Alert.alert('Error', 'Failed to share image');
    }
  };

  // Create PanResponder for drag functionality (works on web)
  const startPos = useRef({ x: 0, y: 0 });
  
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderGrant: () => {
        // Store the initial position when touch starts
        startPos.current = {
          x: translateX.value,
          y: translateY.value,
        };
      },
      onPanResponderMove: (evt, gestureState) => {
        // Update position based on gesture
        translateX.value = startPos.current.x + gestureState.dx;
        translateY.value = startPos.current.y + gestureState.dy;
      },
      onPanResponderRelease: () => {
        // Optionally add spring animation on release
        translateX.value = withSpring(translateX.value);
        translateY.value = withSpring(translateY.value);
      },
    })
  ).current;

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value * revealScale.value },
      { rotate: `${rotation.value + revealRotation.value}deg` },
    ],
    opacity: revealOpacity.value,
  }));

  // Sparkle effect animation style
  const sparkleStyle = useAnimatedStyle(() => ({
    opacity: sparkleOpacity.value,
    transform: [{ scale: sparkleScale.value }],
  }));

  return (
    <View style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'Position Your Twin',
          headerStyle: { backgroundColor: theme.colors.cream },
          headerTintColor: theme.colors.ink,
        }} 
      />
      
      <BlobBackground />
      
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.content}>
          {/* Instructions */}
          <View style={styles.instructionsSection}>
            <Text style={styles.title}>Perfect Your Scene!</Text>
            <Text style={styles.subtitle}>
              Drag to move, pinch to zoom, and position your cartoon twin
            </Text>
          </View>

          {/* Canvas */}
          <ViewShot 
            ref={viewShotRef} 
            style={styles.canvas}
            options={{ format: 'png', quality: 1 }}
          >
            {/* Background Image */}
            <Image 
              source={{ uri: backgroundUri }} 
              style={styles.backgroundImage}
              resizeMode="cover"
            />
            
            {/* Cartoon Overlay */}
            <Animated.View
              style={[styles.cartoonContainer, animatedStyle]}
              {...panResponder.panHandlers}
            >
              <Image
                source={{ uri: cartoonInPoseUri }}
                style={styles.cartoonImage}
                resizeMode="contain"
              />

              {/* Sparkle Effect Overlay */}
              <Animated.View style={[styles.sparkleContainer, sparkleStyle]}>
                <View style={[styles.sparkle, styles.sparkleTopLeft]}>
                  <Text style={styles.sparkleText}>✨</Text>
                </View>
                <View style={[styles.sparkle, styles.sparkleTopRight]}>
                  <Text style={styles.sparkleText}>⭐</Text>
                </View>
                <View style={[styles.sparkle, styles.sparkleBottom]}>
                  <Text style={styles.sparkleText}>🌟</Text>
                </View>
              </Animated.View>
            </Animated.View>
          </ViewShot>

          {/* Control Buttons */}
          <View style={styles.controlsSection}>
            <Text style={styles.controlsTitle}>Quick Controls</Text>
            <View style={styles.controlButtons}>
              <TouchableOpacity style={styles.controlButton} onPress={handleZoomIn}>
                <ZoomIn size={20} color={theme.colors.ink} />
                <Text style={styles.controlButtonText}>Zoom In</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.controlButton} onPress={handleZoomOut}>
                <ZoomOut size={20} color={theme.colors.ink} />
                <Text style={styles.controlButtonText}>Zoom Out</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.controlButton} onPress={handleRotate}>
                <RotateCw size={20} color={theme.colors.ink} />
                <Text style={styles.controlButtonText}>Rotate</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.controlButton} onPress={handleReset}>
                <RefreshCw size={20} color={theme.colors.ink} />
                <Text style={styles.controlButtonText}>Reset</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.actionSection}>
            <WobblyButton 
              onPress={handleSaveScene}
              size="large"
              disabled={isSaving}
            >
              {isSaving ? 'Saving...' : 'Save Your Scene! 🎨'}
            </WobblyButton>
          </View>

          {/* Tips */}
          <View style={styles.tipsSection}>
            <Text style={styles.tipText}>
              💡 Tip: Drag the cartoon to position it, use the buttons to zoom and rotate
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingBottom: theme.spacing.xl,
  },
  instructionsSection: {
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.xl,
    paddingBottom: theme.spacing.md,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.ink,
    marginBottom: theme.spacing.sm,
  },
  subtitle: {
    fontSize: 16,
    color: theme.colors.sketch,
    textAlign: 'center',
    lineHeight: 22,
  },
  canvas: {
    marginHorizontal: theme.spacing.lg,
    height: CANVAS_HEIGHT,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 2,
    borderColor: theme.colors.coral,
    overflow: 'hidden',
    position: 'relative',
  },
  backgroundImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  cartoonContainer: {
    position: 'absolute',
    width: 150,
    height: 200,
    // No background - cartoon now has real transparency from remove.bg
    backgroundColor: 'transparent',
    // Add subtle shadow for better visibility
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 5,
  },
  cartoonImage: {
    width: '100%',
    height: '100%',
    backgroundColor: 'transparent',
    resizeMode: 'contain',
  },
  controlsSection: {
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.lg,
  },
  controlsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.ink,
    marginBottom: theme.spacing.md,
  },
  controlButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: theme.spacing.sm,
  },
  controlButton: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
    paddingVertical: theme.spacing.md,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.md,
    borderWidth: 1,
    borderColor: theme.colors.sketch + '30',
  },
  controlButtonText: {
    fontSize: 11,
    fontWeight: '500',
    color: theme.colors.ink,
  },
  actionSection: {
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.xl,
  },
  tipsSection: {
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.lg,
    alignItems: 'center',
  },
  tipText: {
    fontSize: 14,
    color: theme.colors.sketch,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  sparkleContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    pointerEvents: 'none',
  },
  sparkle: {
    position: 'absolute',
  },
  sparkleText: {
    fontSize: 24,
    textAlign: 'center',
  },
  sparkleTopLeft: {
    top: -10,
    left: -10,
  },
  sparkleTopRight: {
    top: -15,
    right: -15,
  },
  sparkleBottom: {
    bottom: -20,
    right: '30%',
  },
});