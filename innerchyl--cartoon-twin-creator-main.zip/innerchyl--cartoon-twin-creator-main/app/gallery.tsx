import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, Alert, Dimensions, RefreshControl } from 'react-native';
import { Stack, router } from 'expo-router';
import { Trash2, Share2, Grid, Download } from 'lucide-react-native';
import BlobBackground from '@/components/BlobBackground';
import { theme } from '@/constants/theme';
import { StorageService, SavedScene } from '@/services/storage';
import * as Sharing from 'expo-sharing';
import * as MediaLibrary from 'expo-media-library';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const ITEM_WIDTH = (SCREEN_WIDTH - theme.spacing.lg * 3) / 2;

export default function GalleryScreen() {
  const [scenes, setScenes] = useState<SavedScene[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedScene, setSelectedScene] = useState<string | null>(null);

  useEffect(() => {
    loadScenes();
  }, []);

  const loadScenes = async () => {
    try {
      const savedScenes = await StorageService.getAllScenes();
      setScenes(savedScenes);
    } catch (error) {
      console.error('Error loading scenes:', error);
    } finally {
      setIsLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    loadScenes();
  };

  const handleDelete = async (sceneId: string) => {
    Alert.alert(
      'Delete Scene',
      'Are you sure you want to delete this scene?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await StorageService.deleteScene(sceneId);
              setScenes(scenes.filter(scene => scene.id !== sceneId));
            } catch (error) {
              Alert.alert('Error', 'Failed to delete scene');
            }
          },
        },
      ]
    );
  };

  const handleShare = async (imageUri: string) => {
    try {
      const isAvailable = await Sharing.isAvailableAsync();
      if (isAvailable) {
        await Sharing.shareAsync(imageUri);
      } else {
        Alert.alert('Sharing not available', 'Sharing is not available on this device');
      }
    } catch (error) {
      console.error('Error sharing:', error);
      Alert.alert('Error', 'Failed to share image');
    }
  };

  const handleSaveToGallery = async (imageUri: string) => {
    try {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'We need permission to save to your gallery');
        return;
      }
      
      await MediaLibrary.saveToLibraryAsync(imageUri);
      Alert.alert('Saved!', 'Image saved to your gallery');
    } catch (error) {
      console.error('Error saving to gallery:', error);
      Alert.alert('Error', 'Failed to save to gallery');
    }
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const renderScene = ({ item }: { item: SavedScene }) => {
    const isSelected = selectedScene === item.id;
    
    return (
      <TouchableOpacity
        style={[styles.sceneCard, isSelected && styles.selectedCard]}
        onPress={() => setSelectedScene(isSelected ? null : item.id)}
        activeOpacity={0.9}
      >
        <Image source={{ uri: item.imageUri }} style={styles.sceneImage} />
        
        {isSelected && (
          <View style={styles.overlay}>
            <View style={styles.actionButtons}>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => handleShare(item.imageUri)}
              >
                <Share2 size={20} color={theme.colors.white} />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => handleSaveToGallery(item.imageUri)}
              >
                <Download size={20} color={theme.colors.white} />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.actionButton, styles.deleteButton]}
                onPress={() => handleDelete(item.id)}
              >
                <Trash2 size={20} color={theme.colors.white} />
              </TouchableOpacity>
            </View>
          </View>
        )}
        
        <View style={styles.sceneInfo}>
          <Text style={styles.sceneDate}>{formatDate(item.timestamp)}</Text>
          {item.caption && <Text style={styles.sceneCaption}>{item.caption}</Text>}
        </View>
      </TouchableOpacity>
    );
  };

  const EmptyGallery = () => (
    <View style={styles.emptyContainer}>
      <Grid size={64} color={theme.colors.sketch} />
      <Text style={styles.emptyTitle}>No Saved Scenes Yet</Text>
      <Text style={styles.emptySubtitle}>
        Create your first cartoon twin and save it to see it here!
      </Text>
      <TouchableOpacity
        style={styles.createButton}
        onPress={() => router.push('/upload')}
      >
        <Text style={styles.createButtonText}>Create Your First Twin</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'My Gallery',
          headerStyle: { backgroundColor: theme.colors.cream },
          headerTintColor: theme.colors.ink,
        }} 
      />
      
      <BlobBackground />
      
      {scenes.length === 0 && !isLoading ? (
        <EmptyGallery />
      ) : (
        <FlatList
          data={scenes}
          renderItem={renderScene}
          keyExtractor={(item) => item.id}
          numColumns={2}
          contentContainerStyle={styles.gridContainer}
          columnWrapperStyle={styles.row}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              colors={[theme.colors.coral]}
              tintColor={theme.colors.coral}
            />
          }
          ListHeaderComponent={
            <View style={styles.header}>
              <Text style={styles.headerTitle}>Your Cartoon Scenes</Text>
              <Text style={styles.headerSubtitle}>
                {scenes.length} {scenes.length === 1 ? 'scene' : 'scenes'} saved
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  gridContainer: {
    paddingHorizontal: theme.spacing.lg,
    paddingBottom: theme.spacing.xl,
  },
  row: {
    justifyContent: 'space-between',
    marginBottom: theme.spacing.md,
  },
  header: {
    paddingVertical: theme.spacing.lg,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.ink,
    marginBottom: theme.spacing.xs,
  },
  headerSubtitle: {
    fontSize: 14,
    color: theme.colors.sketch,
  },
  sceneCard: {
    width: ITEM_WIDTH,
    height: ITEM_WIDTH * 1.3,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.lg,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: theme.colors.coral,
  },
  selectedCard: {
    borderColor: theme.colors.mint,
    borderWidth: 3,
  },
  sceneImage: {
    width: '100%',
    flex: 1,
    resizeMode: 'cover',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: theme.spacing.md,
  },
  actionButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: theme.colors.coral,
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButton: {
    backgroundColor: '#FF6B6B',
  },
  sceneInfo: {
    padding: theme.spacing.sm,
    backgroundColor: theme.colors.white,
  },
  sceneDate: {
    fontSize: 12,
    color: theme.colors.sketch,
    fontWeight: '500',
  },
  sceneCaption: {
    fontSize: 14,
    color: theme.colors.ink,
    marginTop: 2,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.xl,
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: theme.colors.ink,
    marginTop: theme.spacing.lg,
    marginBottom: theme.spacing.sm,
  },
  emptySubtitle: {
    fontSize: 16,
    color: theme.colors.sketch,
    textAlign: 'center',
    marginBottom: theme.spacing.xl,
  },
  createButton: {
    backgroundColor: theme.colors.coral,
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    borderRadius: theme.borderRadius.full,
  },
  createButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.white,
  },
});