import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Grid } from 'lucide-react-native';
import BlobBackground from '@/components/BlobBackground';
import WobblyButton from '@/components/WobblyButton';
import { theme } from '@/constants/theme';
import { StorageService } from '@/services/storage';

export default function SplashScreen() {
  const insets = useSafeAreaInsets();
  const [savedCount, setSavedCount] = useState(0);
  
  useEffect(() => {
    loadSavedCount();
  }, []);
  
  const loadSavedCount = async () => {
    const scenes = await StorageService.getAllScenes();
    setSavedCount(scenes.length);
  };
  
  const handleCreateDouble = () => {
    router.push('/upload');
  };
  
  const handleViewGallery = () => {
    router.push('/gallery');
  };

  return (
    <View style={styles.container}>
      <BlobBackground />
      
      <View style={[styles.safeArea, { paddingTop: insets.top, paddingBottom: insets.bottom }]}>
        <View style={styles.content}>
          {/* Logo Section */}
          <View style={styles.logoSection}>
            <Text style={styles.logo}>innerchyl</Text>
            <Text style={styles.tagline}>Turn yourself into a cartoon twin</Text>
          </View>

          {/* Main Action */}
          <View style={styles.actionSection}>
            <WobblyButton 
              onPress={handleCreateDouble}
              size="large"
            >
              Create Your Double
            </WobblyButton>
            
            {savedCount > 0 && (
              <TouchableOpacity 
                style={styles.galleryButton}
                onPress={handleViewGallery}
              >
                <Grid size={20} color={theme.colors.ink} />
                <Text style={styles.galleryButtonText}>
                  View Gallery ({savedCount})
                </Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Bottom Info */}
          <View style={styles.bottomSection}>
            <Text style={styles.description}>
              Upload your photo and instantly get a cartoon avatar{'\n'}
              matching your pose! Move it around and save ✨
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: theme.spacing.lg,
    justifyContent: 'space-between',
  },
  logoSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: theme.spacing.xxl,
  },
  logo: {
    fontSize: 48,
    fontWeight: '800',
    color: theme.colors.ink,
    textAlign: 'center',
    marginBottom: theme.spacing.md,
    letterSpacing: -1,
  },
  tagline: {
    fontSize: 18,
    color: theme.colors.sketch,
    textAlign: 'center',
    fontWeight: '500',
  },
  actionSection: {
    alignItems: 'center',
    paddingVertical: theme.spacing.xl,
    gap: theme.spacing.lg,
  },
  galleryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.sm,
    paddingHorizontal: theme.spacing.lg,
    paddingVertical: theme.spacing.md,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.full,
    borderWidth: 2,
    borderColor: theme.colors.coral,
  },
  galleryButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.ink,
  },
  bottomSection: {
    paddingBottom: theme.spacing.xl,
    alignItems: 'center',
  },
  description: {
    fontSize: 16,
    color: theme.colors.sketch,
    textAlign: 'center',
    lineHeight: 24,
    fontWeight: '400',
  },
});