import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, Alert, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import { Camera, Upload } from 'lucide-react-native';
import BlobBackground from '@/components/BlobBackground';
import WobblyButton from '@/components/WobblyButton';
import { useImagePicker, PickedImage } from '@/hooks/useImagePicker';
import { theme } from '@/constants/theme';

export default function PoseCaptureScreen() {
  const { cartoonUri } = useLocalSearchParams<{ cartoonUri: string }>();
  const [poseImage, setPoseImage] = useState<PickedImage | null>(null);
  const { pickFromGallery, takePhoto, isLoading } = useImagePicker();
  const insets = useSafeAreaInsets();

  const handleImagePick = async (source: 'gallery' | 'camera') => {
    const image = source === 'gallery' ? await pickFromGallery() : await takePhoto();
    if (image) {
      setPoseImage(image);
    }
  };

  const handleContinue = () => {
    if (!poseImage) {
      Alert.alert('No photo selected', 'Please select a photo with your pose!');
      return;
    }
    
    router.push({
      pathname: '/pose-processing',
      params: { 
        cartoonUri: cartoonUri,
        poseImageUri: poseImage.uri 
      }
    });
  };

  return (
    <View style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'Strike a Pose!',
          headerStyle: { backgroundColor: theme.colors.cream },
          headerTintColor: theme.colors.ink,
        }} 
      />
      
      <BlobBackground />
      
      <View style={[styles.safeArea, { paddingTop: insets.top }]}>
        <View style={styles.content}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerText}>Show Your Pose</Text>
            <Text style={styles.subheaderText}>
              Take a photo in any pose and we'll make your cartoon twin match it!
            </Text>
          </View>

          {/* Preview Section */}
          <View style={styles.previewSection}>
            <View style={styles.twinPreview}>
              <Text style={styles.previewLabel}>Your Cartoon Twin</Text>
              <Image source={{ uri: cartoonUri }} style={styles.twinImage} />
            </View>

            <View style={styles.arrowContainer}>
              <Text style={styles.arrow}>+</Text>
            </View>

            {/* Pose Image or Placeholder */}
            {poseImage ? (
              <View style={styles.posePreview}>
                <Text style={styles.previewLabel}>Your Pose</Text>
                <Image source={{ uri: poseImage.uri }} style={styles.poseImage} />
                <TouchableOpacity 
                  style={styles.changeButton}
                  onPress={() => setPoseImage(null)}
                >
                  <Text style={styles.changeButtonText}>Change</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.posePlaceholder}>
                <Camera size={40} color={theme.colors.sketch} />
                <Text style={styles.placeholderText}>Add Your Pose</Text>
              </View>
            )}
          </View>

          {/* Action Buttons */}
          {!poseImage && (
            <View style={styles.captureButtons}>
              <WobblyButton 
                onPress={() => handleImagePick('camera')}
                variant="secondary"
                size="medium"
                disabled={isLoading}
              >
                Take Photo 📸
              </WobblyButton>
              
              <WobblyButton 
                onPress={() => handleImagePick('gallery')}
                variant="secondary"
                size="medium"
                disabled={isLoading}
              >
                Choose from Gallery 🖼️
              </WobblyButton>
            </View>
          )}

          {/* Tips */}
          <View style={styles.tipsSection}>
            <Text style={styles.tipTitle}>Tips for best results:</Text>
            <Text style={styles.tipText}>• Stand in a clear, fun pose</Text>
            <Text style={styles.tipText}>• Make sure your full body is visible</Text>
            <Text style={styles.tipText}>• Try jumping, dancing, or action poses!</Text>
          </View>

          {/* Continue Button */}
          {poseImage && (
            <View style={styles.actionSection}>
              <WobblyButton 
                onPress={handleContinue}
                size="large"
                disabled={isLoading}
              >
                Create Scene! ✨
              </WobblyButton>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: theme.spacing.lg,
  },
  header: {
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },
  headerText: {
    fontSize: 28,
    fontWeight: '700',
    color: theme.colors.ink,
    textAlign: 'center',
    marginBottom: theme.spacing.sm,
  },
  subheaderText: {
    fontSize: 16,
    color: theme.colors.sketch,
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: theme.spacing.md,
  },
  previewSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: theme.spacing.xl,
    paddingHorizontal: theme.spacing.sm,
  },
  twinPreview: {
    alignItems: 'center',
  },
  posePreview: {
    alignItems: 'center',
    position: 'relative',
  },
  previewLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: theme.colors.sketch,
    marginBottom: theme.spacing.xs,
  },
  twinImage: {
    width: 120,
    height: 120,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 2,
    borderColor: theme.colors.sky,
  },
  poseImage: {
    width: 120,
    height: 120,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 2,
    borderColor: theme.colors.coral,
  },
  posePlaceholder: {
    width: 120,
    height: 120,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 2,
    borderColor: theme.colors.sketch,
    borderStyle: 'dashed',
    backgroundColor: theme.colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    gap: theme.spacing.xs,
  },
  placeholderText: {
    fontSize: 12,
    color: theme.colors.sketch,
    fontWeight: '500',
  },
  arrowContainer: {
    paddingHorizontal: theme.spacing.lg,
  },
  arrow: {
    fontSize: 32,
    fontWeight: '700',
    color: theme.colors.coral,
  },
  changeButton: {
    position: 'absolute',
    bottom: -10,
    backgroundColor: theme.colors.ink,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  changeButtonText: {
    color: theme.colors.white,
    fontSize: 10,
    fontWeight: '600',
  },
  captureButtons: {
    gap: theme.spacing.md,
    marginBottom: theme.spacing.xl,
  },
  tipsSection: {
    backgroundColor: theme.colors.lavender + '20',
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.md,
    marginBottom: theme.spacing.xl,
  },
  tipTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.ink,
    marginBottom: theme.spacing.sm,
  },
  tipText: {
    fontSize: 13,
    color: theme.colors.sketch,
    lineHeight: 20,
    marginBottom: 4,
  },
  actionSection: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: theme.spacing.xl,
  },
});