import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Stack, router } from 'expo-router';
import { User, Check, Sparkles } from 'lucide-react-native';
import BlobBackground from '@/components/BlobBackground';
import WobblyButton from '@/components/WobblyButton';
import { useImagePicker, PickedImage } from '@/hooks/useImagePicker';
import { theme } from '@/constants/theme';

export default function UploadScreen() {
  const [selectedImage, setSelectedImage] = useState<PickedImage | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<string>('charlie-lola');
  const { pickFromGallery, isLoading } = useImagePicker();
  const insets = useSafeAreaInsets();

  const handleImagePick = async () => {
    const image = await pickFromGallery();
    if (image) {
      setSelectedImage(image);
    }
  };

  const handleContinue = async () => {
    if (!selectedImage) {
      Alert.alert('No photo selected', 'Please select a photo to continue!');
      return;
    }

    // Navigate to processing screen with the selected image
    router.push({
      pathname: '/processing',
      params: {
        imageUri: selectedImage.uri,
        selectedStyle: selectedStyle
      }
    });
  };

  return (
    <View style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'Upload Photo',
          headerStyle: { backgroundColor: theme.colors.cream },
          headerTintColor: theme.colors.ink,
        }} 
      />
      
      <BlobBackground />
      
      <View style={[styles.safeArea, { paddingTop: insets.top }]}>
        <View style={styles.content}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.headerText}>pick your photo</Text>
          </View>

          {/* Image Preview */}
          <View style={styles.imageSection}>
            <TouchableOpacity 
              style={[
                styles.photoContainer,
                selectedImage ? styles.photoContainerWithImage : styles.photoContainerEmpty
              ]} 
              onPress={handleImagePick}
              disabled={isLoading}
            >
              {selectedImage ? (
                <Image source={{ uri: selectedImage.uri }} style={styles.previewImage} />
              ) : (
                <View style={styles.placeholderContent}>
                  <User size={48} color={theme.colors.sketch} />
                  <Text style={styles.placeholderText}>tap to add photo</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Style Selection */}
          <View style={styles.styleSection}>
            <Text style={styles.styleTitle}>choose your style</Text>
            
            <View style={styles.styleOptions}>
              <TouchableOpacity 
                style={[
                  styles.styleButton,
                  selectedStyle === 'charlie-lola' && styles.styleButtonSelected
                ]}
                onPress={() => setSelectedStyle('charlie-lola')}
              >
                <Text style={[
                  styles.styleButtonText,
                  selectedStyle === 'charlie-lola' && styles.styleButtonTextSelected
                ]}>charlie & lola</Text>
                {selectedStyle === 'charlie-lola' && (
                  <Check size={16} color={theme.colors.ink} style={styles.checkIcon} />
                )}
              </TouchableOpacity>
              
              <View style={styles.styleButtonDisabled}>
                <Text style={styles.styleButtonTextDisabled}>coming soon</Text>
              </View>
            </View>
          </View>

          {/* Continue Button */}
          <View style={styles.actionSection}>
            <WobblyButton
              onPress={handleContinue}
              size="large"
              disabled={!selectedImage || isLoading}
            >
              create my twin!
            </WobblyButton>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: theme.spacing.lg,
    paddingTop: theme.spacing.xl,
  },
  header: {
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },
  headerText: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.ink,
    textAlign: 'center',
  },
  imageSection: {
    alignItems: 'center',
    marginBottom: theme.spacing.xl,
  },
  photoContainer: {
    width: 280,
    height: 350,
    backgroundColor: theme.colors.white,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  photoContainerEmpty: {
    borderWidth: 3,
    borderColor: theme.colors.ink,
    borderStyle: 'dashed',
  },
  photoContainerWithImage: {
    borderWidth: 3,
    borderColor: '#4ECDC4',
    borderStyle: 'dashed',
  },
  previewImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  placeholderContent: {
    alignItems: 'center',
    gap: theme.spacing.md,
  },
  placeholderText: {
    fontSize: 16,
    color: theme.colors.sketch,
    fontWeight: '500',
  },
  styleSection: {
    marginBottom: theme.spacing.xl,
  },
  styleTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: theme.colors.ink,
    textAlign: 'center',
    marginBottom: theme.spacing.lg,
  },
  styleOptions: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: theme.spacing.md,
  },
  styleButton: {
    backgroundColor: theme.colors.white,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: theme.colors.ink,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  styleButtonSelected: {
    backgroundColor: '#4ECDC4',
  },
  styleButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.ink,
  },
  styleButtonTextSelected: {
    color: theme.colors.ink,
  },
  styleButtonDisabled: {
    backgroundColor: '#E0E0E0',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#CCCCCC',
  },
  styleButtonTextDisabled: {
    fontSize: 16,
    fontWeight: '600',
    color: '#999999',
  },
  checkIcon: {
    marginLeft: 4,
  },
  actionSection: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: theme.spacing.xl,
  },
});