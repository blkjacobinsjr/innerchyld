import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, Alert, Share, Platform } from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import * as MediaLibrary from 'expo-media-library';
import { Download, Share2 } from 'lucide-react-native';
import BlobBackground from '@/components/BlobBackground';
import WobblyButton from '@/components/WobblyButton';
import { API } from '@/services/api';
import { theme } from '@/constants/theme';

export default function ResultsScreen() {
  const { originalUri, cartoonUri, compositeUri } = useLocalSearchParams<{
    originalUri: string;
    cartoonUri: string;
    compositeUri: string;
  }>();
  
  const [isSharing, setIsSharing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveToGallery = async () => {
    try {
      setIsSaving(true);
      
      if (Platform.OS !== 'web') {
        const { status } = await MediaLibrary.requestPermissionsAsync();
        if (status !== 'granted') {
          Alert.alert('Permission needed', 'We need permission to save to your gallery');
          return;
        }
      }

      if (compositeUri) {
        if (Platform.OS === 'web') {
          // Web: Create download link
          const link = document.createElement('a');
          link.href = compositeUri;
          link.download = 'innerchyl-cartoon.jpg';
          link.click();
        } else {
          // Mobile: Save to media library
          await MediaLibrary.saveToLibraryAsync(compositeUri);
        }
        
        Alert.alert('Saved!', 'Your cartoon twin has been saved to your gallery! 🎉');
      }
    } catch (error) {
      console.error('Error saving image:', error);
      Alert.alert('Error', 'Failed to save image');
    } finally {
      setIsSaving(false);
    }
  };

  const handleShare = async (platform?: 'instagram-story' | 'instagram-post' | 'tiktok') => {
    try {
      setIsSharing(true);
      
      if (!compositeUri) return;

      if (platform) {
        const shareData = await API.formatForPlatform(compositeUri, platform);
        
        if (Platform.OS === 'web') {
          // Web: Copy to clipboard
          await navigator.clipboard.writeText(shareData.caption);
          Alert.alert('Copied!', 'Caption copied to clipboard. Open the app to share your image!');
        } else {
          // Mobile: Use native sharing
          await Share.share({
            url: shareData.formattedUrl,
            message: shareData.caption,
          });
        }
      } else {
        // Generic share
        if (Platform.OS === 'web') {
          if (navigator.share) {
            await navigator.share({
              title: 'My Cartoon Twin!',
              text: 'Check out my cartoon twin made with innerchyl! 🎨',
              url: compositeUri,
            });
          } else {
            Alert.alert('Share', 'Right-click the image to save and share!');
          }
        } else {
          await Share.share({
            url: compositeUri,
            message: 'Check out my cartoon twin made with innerchyl! 🎨',
          });
        }
      }
    } catch (error) {
      console.error('Error sharing:', error);
      Alert.alert('Error', 'Failed to share image');
    } finally {
      setIsSharing(false);
    }
  };

  const handleMakeAnother = () => {
    router.push('/upload');
  };

  return (
    <View style={styles.container}>
      <Stack.Screen 
        options={{ 
          title: 'Your Cartoon Twin!',
          headerStyle: { backgroundColor: theme.colors.cream },
          headerTintColor: theme.colors.ink,
        }} 
      />
      
      <BlobBackground />
      
      <View style={styles.safeArea}>
        <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
          <View style={styles.content}>
            {/* Header */}
            <View style={styles.header}>
              <Text style={styles.title}>Ta-da! ✨</Text>
              <Text style={styles.subtitle}>
                Meet your cartoon twin in Charlie & Lola style!
              </Text>
            </View>

            {/* Image Comparison */}
            <View style={styles.imageSection}>
              {originalUri && cartoonUri ? (
                <View style={styles.comparisonContainer}>
                  <View style={styles.imageContainer}>
                    <Text style={styles.imageLabel}>Original You</Text>
                    <Image source={{ uri: originalUri }} style={styles.comparisonImage} />
                  </View>
                  
                  <View style={styles.vsContainer}>
                    <Text style={styles.vsText}>→</Text>
                  </View>
                  
                  <View style={styles.imageContainer}>
                    <Text style={styles.imageLabel}>Cartoon You</Text>
                    <Image source={{ uri: cartoonUri }} style={styles.comparisonImage} />
                  </View>
                </View>
              ) : (
                compositeUri && (
                  <View style={styles.singleImageContainer}>
                    <Image source={{ uri: compositeUri }} style={styles.resultImage} />
                  </View>
                )
              )}
            </View>

            {/* Action Buttons */}
            <View style={styles.actionSection}>
              {/* Save Button */}
              <WobblyButton 
                onPress={handleSaveToGallery}
                variant="secondary"
                size="medium"
                disabled={isSaving}
              >
                {isSaving ? 'Saving...' : 'Save to Gallery'}
              </WobblyButton>

              {/* Share Buttons */}
              <View style={styles.shareSection}>
                <Text style={styles.shareTitle}>Share to:</Text>
                
                <View style={styles.shareButtons}>
                  <WobblyButton 
                    onPress={() => handleShare('instagram-story')}
                    variant="secondary"
                    size="small"
                    disabled={isSharing}
                  >
                    IG Story
                  </WobblyButton>
                  
                  <WobblyButton 
                    onPress={() => handleShare('instagram-post')}
                    variant="secondary"
                    size="small"
                    disabled={isSharing}
                  >
                    IG Post
                  </WobblyButton>
                  
                  <WobblyButton 
                    onPress={() => handleShare('tiktok')}
                    variant="secondary"
                    size="small"
                    disabled={isSharing}
                  >
                    TikTok
                  </WobblyButton>
                </View>

                <WobblyButton 
                  onPress={() => handleShare()}
                  variant="secondary"
                  size="medium"
                  disabled={isSharing}
                >
                  More Options
                </WobblyButton>
              </View>

              {/* Create Scene Button */}
              <WobblyButton 
                onPress={() => router.push({
                  pathname: '/pose-capture',
                  params: { cartoonUri: cartoonUri }
                })}
                variant="primary"
                size="large"
              >
                Create a Scene! 📸
              </WobblyButton>

              {/* Make Another */}
              <WobblyButton 
                onPress={handleMakeAnother}
                variant="secondary"
                size="medium"
              >
                Make Another Twin
              </WobblyButton>
            </View>

            {/* Watermark */}
            <View style={styles.watermarkSection}>
              <Text style={styles.watermarkText}>made with innerchyl ✨</Text>
            </View>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  safeArea: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    paddingHorizontal: theme.spacing.lg,
    paddingBottom: theme.spacing.xl,
  },
  header: {
    paddingVertical: theme.spacing.xl,
    alignItems: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: '800',
    color: theme.colors.ink,
    textAlign: 'center',
    marginBottom: theme.spacing.sm,
  },
  subtitle: {
    fontSize: 16,
    color: theme.colors.sketch,
    textAlign: 'center',
    lineHeight: 22,
  },
  imageSection: {
    paddingVertical: theme.spacing.lg,
  },
  comparisonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  imageContainer: {
    flex: 1,
    alignItems: 'center',
  },
  imageLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: theme.colors.sketch,
    marginBottom: theme.spacing.sm,
  },
  comparisonImage: {
    width: 140,
    height: 140,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 2,
    borderColor: theme.colors.coral,
  },
  vsContainer: {
    paddingHorizontal: theme.spacing.md,
  },
  vsText: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.coral,
  },
  singleImageContainer: {
    alignItems: 'center',
  },
  resultImage: {
    width: 300,
    height: 300,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 3,
    borderColor: theme.colors.coral,
  },
  actionSection: {
    paddingVertical: theme.spacing.xl,
    gap: theme.spacing.lg,
  },
  shareSection: {
    alignItems: 'center',
    gap: theme.spacing.md,
  },
  shareTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: theme.colors.ink,
  },
  shareButtons: {
    flexDirection: 'row',
    gap: theme.spacing.sm,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  watermarkSection: {
    alignItems: 'center',
    paddingTop: theme.spacing.lg,
  },
  watermarkText: {
    fontSize: 12,
    color: theme.colors.sketch,
    fontStyle: 'italic',
  },
});