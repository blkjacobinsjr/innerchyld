import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';

import { Stack, router, useLocalSearchParams } from 'expo-router';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withRepeat, 
  withTiming,
  withSequence,
  interpolate
} from 'react-native-reanimated';
import BlobBackground from '@/components/BlobBackground';
import { API } from '@/services/api';
import { theme } from '@/constants/theme';

const loadingMessages = [
  "Analyzing your photo...",
  "Detecting pose and expression...",
  "Sketching cartoon features...",
  "Adding Charlie & Lola magic...",
  "Finalizing your twin...",
  "Almost ready to play!",
];

export default function ProcessingScreen() {
  const { imageUri, selectedStyle } = useLocalSearchParams<{ imageUri: string; selectedStyle?: string }>();
  const [currentMessage, setCurrentMessage] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const progress = useSharedValue(0);
  const wobble = useSharedValue(0);
  const stripesOffset = useSharedValue(0);

  useEffect(() => {
    // Start wobble animation
    wobble.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1000 }),
        withTiming(-1, { duration: 1000 })
      ),
      -1,
      true
    );

    // Start stripes animation (moving left with decelerating curve)
    stripesOffset.value = withRepeat(
      withTiming(-20, { duration: 2000 }),
      -1,
      true
    );

    // Cycle through loading messages
    const messageInterval = setInterval(() => {
      setCurrentMessage((prev) => (prev + 1) % loadingMessages.length);
    }, 2500);

    // Start processing
    processImage();

    return () => {
      clearInterval(messageInterval);
    };
  }, []);

  const processImage = async () => {
    try {
      if (!imageUri) {
        throw new Error('No image provided');
      }

      // Start with endowed progress (10% immediately)
      progress.value = withTiming(0.1, { duration: 300 });

      // Generate cartoon with pose
      const result = await API.generateCartoonWithPose(imageUri);

      // Non-linear progress: 70% after API call
      progress.value = withTiming(0.7, { duration: 800 });

      // Continue to 95%
      await new Promise(resolve => setTimeout(resolve, 500));
      progress.value = withTiming(0.95, { duration: 600 });

      // Continue to 99% and hold there (99% stall for reliability)
      await new Promise(resolve => setTimeout(resolve, 300));
      progress.value = withTiming(0.99, { duration: 400 });

      // Hold at 99% briefly to simulate final processing
      await new Promise(resolve => setTimeout(resolve, 800));

      // Complete to 100%
      progress.value = withTiming(1, { duration: 200 });

      // Navigate to scene editor
      setTimeout(() => {
        router.replace({
          pathname: '/scene-editor',
          params: {
            cartoonInPoseUri: result.cartoonUrl,
            backgroundUri: result.originalUrl,
            poseDescription: result.poseDescription
          }
        });
      }, 300);

    } catch (err) {
      console.error('Processing error:', err);
      setError(err instanceof Error ? err.message : 'Something went wrong');
    }
  };

  const progressStyle = useAnimatedStyle(() => ({
    width: `${interpolate(progress.value, [0, 1], [0, 100])}%`,
  }));

  const wobbleStyle = useAnimatedStyle(() => ({
    transform: [
      { rotate: `${interpolate(wobble.value, [-1, 1], [-5, 5])}deg` },
      { scale: interpolate(wobble.value, [-1, 1], [0.95, 1.05]) }
    ]
  }));

  const stripesStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: stripesOffset.value }]
  }));

  if (error) {
    return (
      <View style={styles.container}>
        <Stack.Screen options={{ title: 'Processing', headerShown: false }} />
        <BlobBackground />
        
        <View style={styles.safeArea}>
          <View style={styles.content}>
            <View style={styles.errorContainer}>
              <Text style={styles.errorTitle}>Oops! Something went wrong</Text>
              <Text style={styles.errorMessage}>{error}</Text>
              <Text style={styles.retryText} onPress={() => router.back()}>
                Tap to try again
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: 'Processing', headerShown: false }} />
      <BlobBackground />
      
      <View style={styles.safeArea}>
        <View style={styles.content}>
          {/* Drawing Animation */}
          <View style={styles.animationSection}>
            <Animated.View style={[styles.drawingContainer, wobbleStyle]}>
              <Text style={styles.drawingEmoji}>🎨</Text>
            </Animated.View>
          </View>

          {/* Loading Message */}
          <View style={styles.messageSection}>
            <Text style={styles.loadingMessage}>
              {loadingMessages[currentMessage]}
            </Text>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressSection}>
            <View style={styles.progressBar}>
              <Animated.View style={[styles.progressFill, progressStyle]}>
                <Animated.View style={[styles.stripes, stripesStyle]} />
              </Animated.View>
            </View>
          </View>

          {/* Fun Fact */}
          <View style={styles.factSection}>
            <Text style={styles.factText}>
              Did you know? Charlie and Lola was created by Lauren Child and won multiple awards for its unique hand-drawn style! ✨
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: theme.spacing.lg,
    justifyContent: 'center',
  },
  animationSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  drawingContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: theme.colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: theme.colors.ink,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.1,
    shadowRadius: 16,
    elevation: 8,
  },
  drawingEmoji: {
    fontSize: 48,
  },
  messageSection: {
    paddingVertical: theme.spacing.xl,
    alignItems: 'center',
  },
  loadingMessage: {
    fontSize: 24,
    fontWeight: '600',
    color: theme.colors.ink,
    textAlign: 'center',
  },
  progressSection: {
    paddingVertical: theme.spacing.lg,
  },
  progressBar: {
    height: 8,
    backgroundColor: theme.colors.sketch + '30',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: theme.colors.coral,
    borderRadius: 4,
    overflow: 'hidden',
  },
  stripes: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundImage: 'repeating-linear-gradient(45deg, rgba(255,255,255,0.2) 0px, rgba(255,255,255,0.2) 4px, transparent 4px, transparent 8px)',
  },
  factSection: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: theme.spacing.xl,
  },
  factText: {
    fontSize: 14,
    color: theme.colors.sketch,
    textAlign: 'center',
    lineHeight: 20,
    fontStyle: 'italic',
  },
  errorContainer: {
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
  },
  errorTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: theme.colors.ink,
    textAlign: 'center',
    marginBottom: theme.spacing.md,
  },
  errorMessage: {
    fontSize: 16,
    color: theme.colors.sketch,
    textAlign: 'center',
    marginBottom: theme.spacing.lg,
    lineHeight: 22,
  },
  retryText: {
    fontSize: 16,
    color: theme.colors.coral,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
});