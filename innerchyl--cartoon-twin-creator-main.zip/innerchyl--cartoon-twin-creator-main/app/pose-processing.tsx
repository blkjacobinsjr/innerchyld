import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Stack, router, useLocalSearchParams } from 'expo-router';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withRepeat, 
  withTiming,
  withSequence,
  interpolate
} from 'react-native-reanimated';
import BlobBackground from '@/components/BlobBackground';
import { API } from '@/services/api';
import { theme } from '@/constants/theme';

const loadingMessages = [
  "Analyzing your pose...",
  "Teaching your twin the moves...",
  "Matching the position...",
  "Adding cartoon magic...",
  "Almost ready...",
];

export default function PoseProcessingScreen() {
  const { cartoonUri, poseImageUri } = useLocalSearchParams<{ 
    cartoonUri: string;
    poseImageUri: string;
  }>();
  const [currentMessage, setCurrentMessage] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const progress = useSharedValue(0);
  const bounce = useSharedValue(0);

  useEffect(() => {
    // Start bounce animation
    bounce.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 500 }),
        withTiming(0, { duration: 500 })
      ),
      -1,
      true
    );

    // Cycle through loading messages
    const messageInterval = setInterval(() => {
      setCurrentMessage((prev) => (prev + 1) % loadingMessages.length);
    }, 2500);

    // Start processing
    processCartoonPose();

    return () => {
      clearInterval(messageInterval);
    };
  }, []);

  const processCartoonPose = async () => {
    try {
      if (!cartoonUri || !poseImageUri) {
        throw new Error('Missing required images');
      }

      // Simulate progress
      progress.value = withTiming(0.3, { duration: 1500 });

      // Generate cartoon in pose
      const result = await API.generateCartoonInPose(cartoonUri, poseImageUri);
      
      progress.value = withTiming(1, { duration: 1000 });

      // Navigate to scene editor
      setTimeout(() => {
        router.replace({
          pathname: '/scene-editor',
          params: {
            cartoonInPoseUri: result.cartoonInPoseUrl,
            backgroundUri: poseImageUri,
            poseDescription: result.poseDescription,
          }
        });
      }, 1000);

    } catch (err) {
      console.error('Processing error:', err);
      setError(err instanceof Error ? err.message : 'Something went wrong');
    }
  };

  const progressStyle = useAnimatedStyle(() => ({
    width: `${interpolate(progress.value, [0, 1], [0, 100])}%`,
  }));

  const bounceStyle = useAnimatedStyle(() => ({
    transform: [
      { translateY: interpolate(bounce.value, [0, 1], [0, -20]) }
    ]
  }));

  if (error) {
    return (
      <View style={styles.container}>
        <Stack.Screen options={{ title: 'Processing', headerShown: false }} />
        <BlobBackground />
        
        <View style={styles.safeArea}>
          <View style={styles.content}>
            <View style={styles.errorContainer}>
              <Text style={styles.errorTitle}>Oops! 😅</Text>
              <Text style={styles.errorMessage}>{error}</Text>
              <Text style={styles.retryText} onPress={() => router.back()}>
                Tap to try again
              </Text>
            </View>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: 'Processing', headerShown: false }} />
      <BlobBackground />
      
      <View style={styles.safeArea}>
        <View style={styles.content}>
          {/* Animation */}
          <View style={styles.animationSection}>
            <Animated.View style={[styles.animationContainer, bounceStyle]}>
              <Text style={styles.animationEmoji}>🤸</Text>
            </Animated.View>
          </View>

          {/* Loading Message */}
          <View style={styles.messageSection}>
            <Text style={styles.loadingMessage}>
              {loadingMessages[currentMessage]}
            </Text>
          </View>

          {/* Progress Bar */}
          <View style={styles.progressSection}>
            <View style={styles.progressBar}>
              <Animated.View style={[styles.progressFill, progressStyle]} />
            </View>
          </View>

          {/* Fun Fact */}
          <View style={styles.factSection}>
            <Text style={styles.factText}>
              Fun fact: Your cartoon twin can match any pose - from yoga stretches to dance moves! 🕺💃
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.cream,
  },
  safeArea: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: theme.spacing.lg,
    justifyContent: 'center',
  },
  animationSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  animationContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: theme.colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: theme.colors.ink,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
  },
  animationEmoji: {
    fontSize: 48,
  },
  messageSection: {
    paddingVertical: theme.spacing.xl,
    alignItems: 'center',
  },
  loadingMessage: {
    fontSize: 24,
    fontWeight: '600',
    color: theme.colors.ink,
    textAlign: 'center',
  },
  progressSection: {
    paddingVertical: theme.spacing.lg,
  },
  progressBar: {
    height: 8,
    backgroundColor: theme.colors.sketch + '30',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: theme.colors.sky,
    borderRadius: 4,
  },
  factSection: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingBottom: theme.spacing.xl,
  },
  factText: {
    fontSize: 14,
    color: theme.colors.sketch,
    textAlign: 'center',
    lineHeight: 20,
    fontStyle: 'italic',
  },
  errorContainer: {
    alignItems: 'center',
    paddingHorizontal: theme.spacing.lg,
  },
  errorTitle: {
    fontSize: 32,
    fontWeight: '700',
    color: theme.colors.ink,
    textAlign: 'center',
    marginBottom: theme.spacing.md,
  },
  errorMessage: {
    fontSize: 16,
    color: theme.colors.sketch,
    textAlign: 'center',
    marginBottom: theme.spacing.lg,
    lineHeight: 22,
  },
  retryText: {
    fontSize: 16,
    color: theme.colors.coral,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
});