// Configuration for external services
export const config = {
  // Google Gemini API Configuration
  // Get your API key from: https://makersuite.google.com/app/apikey
  GEMINI_API_KEY: process.env.EXPO_PUBLIC_GEMINI_API_KEY || 'YOUR_GEMINI_API_KEY_HERE',
  
  // API Endpoints
  GEMINI_API_URL: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent',
  GEMINI_IMAGE_API_URL: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image-preview:generateContent', // Nano Banana - can generate images!
  // Deprecated - removed proprietary API URL
  
  // Background Removal Service Selection
  // Options: 'REMOVE.BG' (50 free/month, best quality) or 'HUGGINGFACE' (unlimited free)
  BACKGROUND_REMOVAL_SERVICE: 'HUGGINGFACE',
  
  // Remove.bg API for background removal (50 free images/month)
  REMOVE_BG_API_KEY: process.env.EXPO_PUBLIC_REMOVE_BG_API_KEY || 'YOUR_REMOVE_BG_API_KEY_HERE',
  REMOVE_BG_API_URL: 'https://api.remove.bg/v1.0/removebg',
  
  // HuggingFace Background Removal (Unlimited FREE)
  HUGGINGFACE_BG_REMOVAL_URL: 'https://not-lain-background-removal.hf.space/gradio_api/call/text',
  HF_TOKEN: process.env.EXPO_PUBLIC_HF_TOKEN || '', // Optional for priority queue
};