export const theme = {
  colors: {
    // Primary palette (bright, inviting)
    coral: '#FF6B6B',
    sunshine: '#FFE66D',
    sky: '#4ECDC4',
    lavender: '#C9AFF0',
    mint: '#A8E6CF',
    
    // UI colors (black/white base)
    ink: '#2B2B2B',
    paper: '#FFF8F3',
    cream: '#FFF8F3',
    sketch: '#4A4A4A',
    white: '#FFFFFF',
    
    // Gradients for UI elements only
    gradientStart: '#FF6B6B',
    gradientEnd: '#FFE66D',
  },
  
  fonts: {
    heading: 'System',
    body: 'System',
    button: 'System'
  },
  
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  
  borderRadius: {
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    blob: 25,
  }
};

export const PLATFORM_SPECS = {
  instagramStory: { ratio: 9/16, maxSize: 4096 },
  instagramPost: { ratio: 1, maxSize: 1080 },
  tiktok: { ratio: 9/16, maxSize: 1080 }
};