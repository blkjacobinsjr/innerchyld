import { useState } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { Alert, Platform } from 'react-native';

export interface PickedImage {
  uri: string;
  width: number;
  height: number;
  type?: string;
}

export function useImagePicker() {
  const [isLoading, setIsLoading] = useState(false);

  const requestPermissions = async () => {
    if (Platform.OS !== 'web') {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert(
          'Permission needed',
          'We need access to your photos to create your cartoon twin!',
          [{ text: 'OK' }]
        );
        return false;
      }
    }
    return true;
  };

  const pickFromGallery = async (): Promise<PickedImage | null> => {
    try {
      setIsLoading(true);
      
      const hasPermission = await requestPermissions();
      if (!hasPermission) return null;

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
        base64: true, // Request base64 data directly
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        // If base64 is available, create a data URI
        const uri = asset.base64 
          ? `data:image/jpeg;base64,${asset.base64}`
          : asset.uri;
        return {
          uri,
          width: asset.width,
          height: asset.height,
          type: asset.type,
        };
      }
      return null;
    } catch (error) {
      console.error('Error picking image from gallery:', error);
      Alert.alert('Error', 'Failed to pick image from gallery');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const takePhoto = async (): Promise<PickedImage | null> => {
    try {
      setIsLoading(true);

      if (Platform.OS !== 'web') {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== 'granted') {
          Alert.alert(
            'Permission needed',
            'We need camera access to take your photo!',
            [{ text: 'OK' }]
          );
          return null;
        }
      }

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
        base64: true, // Request base64 data directly
      });

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        // If base64 is available, create a data URI
        const uri = asset.base64 
          ? `data:image/jpeg;base64,${asset.base64}`
          : asset.uri;
        return {
          uri,
          width: asset.width,
          height: asset.height,
          type: asset.type,
        };
      }
      return null;
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo');
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    pickFromGallery,
    takePhoto,
    isLoading,
  };
}